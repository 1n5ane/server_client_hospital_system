#include <stdio.h>
#include <stdlib.h>
#include "buffer.h"


Circular_buffer * buff_alloc(void){
  Circular_buffer * tmp;
  do{
    tmp=malloc(sizeof(Circular_buffer));
  }while(tmp==NULL);
  return tmp;
}

int buff_init(Circular_buffer * bptr,int size){
  if(bptr==NULL || size==0)
    return 1;
  bptr->size=0;
  bptr->tail=0;
  bptr->head=0;
  bptr->max=size;
  do{
    bptr->array=malloc(size*sizeof(Thr_instr *));
  }while(bptr->array==NULL);
  for(int i=0;i<size;i++)
    bptr->array[i]=NULL;
  return 0;
}

void buff_reset(Circular_buffer * bptr){
  bptr->tail=0;
  bptr->head=0;
  bptr->size=0;
  return ;
}
void buff_destroy(Circular_buffer * bptr){
  free(bptr->array);
  return ;
}
int buff_full(Circular_buffer * bptr){//returns 1 if buff full,else 0
  return bptr->size==bptr->max;
}
int buff_empty(Circular_buffer * bptr){//returns 1 if buff empty,else 0
  return bptr->size==0;
}

int get_capacity(Circular_buffer * bptr){
  return  bptr->max;
}

int get_cur_size(Circular_buffer * bptr){
  return bptr->size;
}

int buff_add(Circular_buffer * bptr,int fd,enum thr_work op){//returns 1 if problem-->buffer may be full
  if(buff_full(bptr))
    return 1;
  bptr->size++;
  Thr_instr * instr;
  do{
    instr=malloc(sizeof(Thr_instr));
  }while(instr==NULL);
  instr->fd=fd;
  instr->operation=op;
  bptr->array[bptr->head]=instr;
  bptr->head=(bptr->head+1)%bptr->max;
  return 0;
}
Thr_instr * buff_get(Circular_buffer * bptr){//get array[tail] and advance tail
  if(buff_empty(bptr))
    return NULL;
  Thr_instr * tmp=bptr->array[bptr->tail];
  bptr->size--;
  bptr->tail=(bptr->tail+1)%bptr->max;
  return tmp;
}
