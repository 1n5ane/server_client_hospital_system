#ifndef __BUFFER_H__
#define __BUFFER_H__
#include "thread_instructions.h"

typedef struct circular_buffer{
  Thr_instr ** array;
  int tail;//tail incremented when item removed
  int head;//head incremented when item added
  int size;
  int max;//capacity of buffer
}Circular_buffer;
Circular_buffer * buff_alloc(void);
int buff_init(Circular_buffer * bptr,int size);//returns 1 if error
void buff_reset(Circular_buffer * bptr);
void buff_destroy(Circular_buffer * bptr);
int buff_full(Circular_buffer * bptr);//returns 1 if buff full,else 0
int buff_empty(Circular_buffer * bptr);//returns 1 if buff empty,else 0
int get_capacity(Circular_buffer * bptr);
int get_cur_size(Circular_buffer * bptr);
int buff_add(Circular_buffer * bptr,int fd,enum thr_work op);//returns 1 if problem-->buffer may be full
Thr_instr * buff_get(Circular_buffer * bptr);//get array[tail] and advance tail

#endif
