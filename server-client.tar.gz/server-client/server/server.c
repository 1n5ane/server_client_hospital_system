#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <poll.h>
#include <signal.h>
#include <unistd.h>
#include <pthread.h>
#include <fcntl.h>
#include <semaphore.h>
#include "../topk_ages_rec.h"
#include "../safe_io.h"
#include "buffer/buffer.h"//for circular buffer
#include "worker_info.h"

void my_handler(int signo){
  if(signo==SIGPIPE);
    //only override the behaviour to terminate
}

enum worker_operations{SUMMARY_STATS,DISEASE_FREQUENCY,TOPK_AGERANGES,SEARCH_PATIENT,NUMPADMISSIONS,NUMPDISCHARGES,MY_INFO};
sem_t notif_sem_main_thread;//if circulasr buffer iss full main thread should sleep until notified that there is space in buffer
pthread_cond_t thread_cond=PTHREAD_COND_INITIALIZER;;
pthread_mutex_t buffer_mutex;
pthread_mutex_t con_with_worker_mutex;
int con_with_worker_counter=0;
pthread_mutex_t worker_info_mutex;
int SUCCESS=0;
int FAIL=0;
Worker_info * worker_info=NULL;//server need to find out which countries belong to which worker
                          //THIS IS THE OPERATION MY_INFO WHERE WORKERS STATE ID(0-(N-1)) country num and countriy names
int w_info_size=0;
int DONE_WITH_WORKER_INFO=0;
typedef struct sockaddr_in sockaddr_in;
typedef struct in_addr in_addr;
typedef struct sockaddr sockaddr;
int TM_WAIT=0;

void * server_thread(void * argp){
  Circular_buffer *circ_buffer=(Circular_buffer *)argp;
  Thr_instr * instr;
  struct pollfd poll_fd[2];
  poll_fd[0].events=POLLIN;
  poll_fd[1].events=POLLIN;
  char read_buffer[500];
  int buffersize=500;
  int * bytes;
  uint8_t output[10240];//10 kb
  int output_len;
  uint8_t * data;
  enum worker_operations * op_read;
  while(1){
    pthread_mutex_lock(&buffer_mutex);//acquire lock
    while(buff_empty(circ_buffer))
      pthread_cond_wait(&thread_cond,&buffer_mutex);

    instr=buff_get(circ_buffer);//need to free the Tht_instr pointer

  /*pthread_mutex_lock(&con_with_worker_mutex);
  con_with_worker_counter++;
  if(con_with_worker_counter%50==0)
    printf("\033[1m\033[31m\t-%d connections with worker-\033[0m\n",con_with_worker_counter);
  pthread_mutex_unlock(&con_with_worker_mutex);*/
    if(get_cur_size(circ_buffer)==get_capacity(circ_buffer)-1)//if before removal the buffer was full wake up main thread that may be sleeping...
      sem_post(&notif_sem_main_thread);
    pthread_mutex_unlock(&buffer_mutex);
    poll_fd[0].fd=instr->fd;
    int ret_val;
    ret_val=poll(poll_fd,(unsigned long)1,-1);//poll forever until data is available for read;
  // printf("IM %ld\n",pthread_self());

    if(ret_val<0){//interrupt maybe

    }else if(ret_val!=0){
      if((poll_fd[0].revents&POLLIN) == POLLIN)
        switch(instr->operation){
          case GET_WORKER_STATS:
            free(instr);
            //exw 2 cases ---> SUMMARY_STATS kai MY_INFO --> me to my info pairnw antixtoia worker_id kai poies xwres exei
            //gia na xerw pou tha prowthw ta erwthmata gia na mhn floodaretai to diktio me askoph kinhsh
            output_len=0;
            bytes=(int *)pipe_read(poll_fd[0].fd,(uint8_t *)read_buffer,buffersize,sizeof(int));
            if(bytes==NULL){//means something happend to the other end while trying to write
              break;
            }
            op_read=(enum worker_operations *)pipe_read(poll_fd[0].fd,(uint8_t *)read_buffer,buffersize,sizeof(enum worker_operations));
            if(op_read==NULL){//means something happend to the other end while trying to write
              break;
            }
            switch (*op_read){
              case SUMMARY_STATS:;
                  free(op_read);
                  int disease_num=*bytes;
                  free(bytes);
                  Topk_ages_rec rec_array[5];
                  for(int j=0;j<2;j++){//first loop for date ->second for country
                    bytes=(int *)pipe_read(poll_fd[0].fd,(uint8_t *)read_buffer,buffersize,sizeof(int));//how big is the str
                    data=(uint8_t *)pipe_read(poll_fd[0].fd,(uint8_t *)read_buffer,buffersize,*bytes);//the str itself
                    if(bytes==NULL || data==NULL)//means something happend to the other end while trying to write
                      break;

                    free(bytes);//free the malloced space

                    output_len+=sprintf(output+output_len,"%s\n",(char *)data);//print the str
                    free(data);//free the string's malloced space
                  }

                  for(int j=0;j<disease_num;j++){
                    bytes=(int *)pipe_read(poll_fd[0].fd,(uint8_t *)read_buffer,buffersize,sizeof(int));//how big is the disease
                  // printf("BYTES %d\n",*bytes);
                    data=(uint8_t *)pipe_read(poll_fd[0].fd,(uint8_t *)read_buffer,buffersize,*bytes);//the disease itself
                    if(bytes==NULL || data==NULL)//means something happend to the other end while trying to write
                      break;
                    output_len+=sprintf(output+output_len,"%s\n",data);
                    free(bytes);
                    free(data);
                    bytes=(int *)pipe_read(poll_fd[0].fd,(uint8_t *)read_buffer,buffersize,sizeof(int));//how big is the data

                    data=(uint8_t *)pipe_read(poll_fd[0].fd,(uint8_t *)read_buffer,buffersize,*bytes);//summary stats counters
                    if(bytes==NULL || data==NULL)//means something happend to the other end while trying to write
                      break;
                    free(bytes);
                    get_topk_from_raw_data(rec_array,data,4);

                    for(int m=0;m<4;m++){
                      output_len+=sprintf(output+output_len,"Age range %s years: %d cases\n",rec_array[m].category,rec_array[m].counter);
                      destroy_topk(&rec_array[m]);
                    }
                    free(data);

                  }
                  write(0,output,output_len);//print the whole output to stdout
                  break;
              case MY_INFO:;
                  int w_id=*bytes;
                  int c_len;
                  free(bytes);
                  free(op_read);

                  bytes=(int *)pipe_read(poll_fd[0].fd,(uint8_t *)read_buffer,buffersize,sizeof(int));//how many countries
                  if(bytes==NULL){//something happened...
                    break;
                  }
                  pthread_mutex_lock(&worker_info_mutex);

                  if(worker_info==NULL){
                    do{
                      worker_info=malloc((w_id+1)*sizeof(Worker_info));
                    }while(worker_info==NULL);
                    w_info_size=w_id+1;
                  }else if((w_id+1)>w_info_size){
                    do{
                      worker_info=realloc(worker_info,(w_id+1)*sizeof(Worker_info));
                    }while(worker_info==NULL);
                    w_info_size=w_id+1;
                  }
                  worker_info[w_id].c_size=*bytes;
          // printf("--------FOR WORKET %d -> %d countries\n",w_id,*bytes);
                  do{
                    worker_info[w_id].countries=malloc(*bytes*sizeof(char *));
                  }while(worker_info[w_id].countries==NULL);
                  data=pipe_read(poll_fd[0].fd,(uint8_t *)read_buffer,buffersize,sizeof(unsigned short));//read the port

                  unsigned short pport=*(unsigned short*)data;

                  socklen_t l=sizeof(worker_info[w_id].addr);
                  if(getpeername(poll_fd[0].fd,(sockaddr *)&worker_info[w_id].addr,&l)<0){
                    perror("getpeername error");
                    exit(1);
                  }
                  worker_info[w_id].addr.sin_family=AF_INET;
                  worker_info[w_id].addr.sin_port=pport;//in network byte order
                  pthread_mutex_unlock(&worker_info_mutex);

                  free(data);
                  free(bytes);
                  for(int k=0;k<worker_info[w_id].c_size;k++){
                    data=(uint8_t *)pipe_read(poll_fd[0].fd,(uint8_t *)read_buffer,buffersize,sizeof(int));//len of country
                    if(data==NULL){//something happened
                      printf("Something happened! line 163 server.c");
                      exit(1);
                    }
                    c_len=*data;
                    free(data);
                    data=(uint8_t *)pipe_read(poll_fd[0].fd,(uint8_t *)read_buffer,buffersize,c_len);//then the country
                    pthread_mutex_lock(&worker_info_mutex);

                    worker_info[w_id].countries[k]=data;
            // printf("%s\n",worker_info[w_id].countries[k]);

                    pthread_mutex_unlock(&worker_info_mutex);
                  }
                  data=NULL;

            }
            shutdown(poll_fd[0].fd,SHUT_RDWR);
            close(poll_fd[0].fd);
            break;

          case GET_CLIENT_REQUEST:
          //sthn periptwsh auth rwtaw katalhlo worker kai perimeno na parw apanthsh gia na thn tipwsw kai na thn epistepsw ston client
            free(instr);
            output_len=0;
            bytes=(int *)pipe_read(poll_fd[0].fd,(uint8_t *)read_buffer,buffersize,sizeof(int));//read from client how many bytes are written
            if(bytes==NULL){//means something happend to the other end while trying to write
              // perror("read fail line 195");
              break;
            }
  // printf(".................IM IN CLIENT REQUEST.......................\n");
            char small_buffer[10];
            char virus_buffer[50];
            char country_buffer[50];
            char date1[15];
            char date2[15];
            int len;
            int c_flag;
            int words_in_line;
            int dead_fd_flag;
            Topk_ages_rec rec_array[5];
            int bytes_to_read;
            enum worker_operations user_ch;
            char * user_input;
            char user_choice[50];
            user_input=(char *)pipe_read(poll_fd[0].fd,(uint8_t *)read_buffer,buffersize,*bytes);//read he request;
            free(bytes);
            len=strlen(user_input);
            if(user_input[len-1]=='\n'){
              user_input[len-1]='\0';
              len--;
            }
            words_in_line=word_count(user_input);
            sscanf(user_input,"%s",user_choice);

            if(!strcmp("/diseaseFrequency",user_choice)){
              user_ch=DISEASE_FREQUENCY;
            }else if(!strcmp("/topk-AgeRanges",user_choice)){
              user_ch=TOPK_AGERANGES;
            }else if(!strcmp("/searchPatientRecord",user_choice)){
              user_ch=SEARCH_PATIENT;
            }else if(!strcmp("/numPatientAdmissions",user_choice)){
              user_ch=NUMPADMISSIONS;
            }else if(!strcmp("/numPatientDischarges",user_choice)){
              user_ch=NUMPDISCHARGES;
            }
            int something_happened=0;
            struct pollfd *mul_ans_fd=NULL;
            int mul_ans_size=0;
            int freq_sum=0;
            int counter=0;
            switch(user_ch){
              case TOPK_AGERANGES:

                sscanf(user_input+strlen(user_choice)+1,"%s %s %s %s %s",small_buffer,country_buffer,virus_buffer,date1,date2);

                len=strlen(user_input+strlen(user_choice)+1);
                c_flag=0;
                dead_fd_flag=0;
                for(int i=0;i<w_info_size;i++)
                  for(int j=0;j<worker_info[i].c_size;j++)
                    if(!strcmp(worker_info[i].countries[j],country_buffer)){//found the correct worker
                      c_flag=1;
                      do{
                        poll_fd[1].fd=socket(worker_info[i].addr.sin_family,SOCK_STREAM,0);
                      }while(poll_fd[1].fd==-1);
                      do{
                        mul_ans_fd=malloc(1*sizeof(struct pollfd));
                      }while(mul_ans_fd==NULL);
                      mul_ans_size=1;
                  // printf("---------CONNECTING WITH WORKER\n");

                      if(connect(poll_fd[1].fd,(struct sockaddr *)&worker_info[i].addr,sizeof(worker_info[i].addr))<0){
                        perror("\033[1m\033[31m\t-Handshake failed [WORKER MAY BE DEAD]-\033[0m");
                        dead_fd_flag=1;
                        break;
                      }
                      pthread_mutex_lock(&con_with_worker_mutex);
                      con_with_worker_counter++;
                      pthread_mutex_unlock(&con_with_worker_mutex);
                      mul_ans_fd[0].fd=poll_fd[1].fd;
                      mul_ans_fd[0].events=POLLIN;
                      if(safe_write(poll_fd[1].fd,(uint8_t *)&len,sizeof(int))==-1){//how many bytes
                        dead_fd_flag=1;
                    // perror("------write fail line 266");
                        something_happened=1;
                        break;
                      }
                      if(safe_write(poll_fd[1].fd,(uint8_t *)&user_ch,sizeof(enum worker_operations))==-1){//which operation
                        dead_fd_flag=1;
                        // perror("-----write fail line 274");
                        something_happened=1;
                        break;
                      }
                      if(safe_write(poll_fd[1].fd,(uint8_t *)(user_input+strlen(user_choice)+1),len)==-1){//the message
                        dead_fd_flag=1;
                        // perror("-----write fail line 284");
                        something_happened=1;
                        break;
                      }
                    }
                if(c_flag==0){
                  FAIL++;
                  printf("No such country [%s]!\n",user_input);
                  something_happened=1;
                }else if(dead_fd_flag==1){
                  printf("Error occured [%s]!\n",user_input);
                  FAIL++;
                  shutdown(poll_fd[0].fd,SHUT_RDWR);//end the connection with client
                  close(poll_fd[0].fd);//close the descriptor
                  something_happened=1;
                }else{//means succeafully sent the request to worker
                      //GOT TO WAIT FOR ANSWER AND THEN FORWARD IT TO CLIENT
                  SUCCESS++;
                }
                break;
              case SEARCH_PATIENT:

                sscanf(user_input+strlen(user_choice)+1,"%s",country_buffer);//dont be confused !! the country buff in this case contains id
          //inform all the guys to keep an eye
                len=strlen(country_buffer)+1;
                do{
                  mul_ans_fd=malloc(w_info_size*sizeof(struct pollfd));
                }while(mul_ans_fd==NULL);
                for(int i=0;i<w_info_size;i++){
                  mul_ans_fd[i].fd=-1;//initialize
                  mul_ans_fd[i].events=POLLIN;//im interested in when bytes show up in socket
                }
                mul_ans_size=w_info_size;
                for(int i=0;i<w_info_size;i++){
                  do{
                    poll_fd[1].fd=socket(worker_info[i].addr.sin_family,SOCK_STREAM,0);
                  }while(poll_fd[1].fd==-1);
        // printf("---------CONNECTING WITH WORKER\n");

                  if(connect(poll_fd[1].fd,(struct sockaddr *)&worker_info[i].addr,sizeof(worker_info[i].addr))<0){
                    perror("\033[1m\033[31m\t-Handshake failed-[WORKER MAY BE DEAD]\033[0m");
                    dead_fd_flag=1;
                  }


                  mul_ans_fd[i].fd=poll_fd[1].fd;
                  if(safe_write(poll_fd[1].fd,(uint8_t *)&len,sizeof(int))==-1){//how many bytes
                    something_happened=1;
                  }
                  if(safe_write(poll_fd[1].fd,(uint8_t *)&user_ch,sizeof(enum worker_operations))==-1){//which operation
                    something_happened=1;

                  }
                  if(safe_write(poll_fd[1].fd,(uint8_t *)country_buffer,len)==-1){//the message
                    something_happened=1;
                  }
                }
                if(!something_happened)
                  SUCCESS++;
                else{
                  FAIL++;
                  printf("\033[1m\033[31m\t An error occured [%s]\033[0m\n",user_input);
                  shutdown(poll_fd[0].fd,SHUT_RDWR);//end the connection with client
                  close(poll_fd[0].fd);//close the descriptor
                }
                break;
              case DISEASE_FREQUENCY:
              case NUMPADMISSIONS:
              case NUMPDISCHARGES:
                      ;
                char * countr_name=NULL;
                if(words_in_line==4){
                  sscanf(user_input+strlen(user_choice)+1,"%s %s %s",virus_buffer,date1,date2);
                }else if(words_in_line==5){
                  sscanf(user_input+strlen(user_choice)+1,"%s %s %s %s",virus_buffer,date1,date2,country_buffer);
                  countr_name=country_buffer;
                }

                len=strlen(user_input+strlen(user_choice)+1)+1;
                dead_fd_flag=0;
                if(countr_name==NULL){//inform all the ohers

                  do{
                    mul_ans_fd=malloc(w_info_size*sizeof(struct pollfd));
                  }while(mul_ans_fd==NULL);
                  for(int i=0;i<w_info_size;i++){
                    mul_ans_fd[i].fd=-1;//initialize
                    mul_ans_fd[i].events=POLLIN;//im interested in when bytes show up in socket
                  }
                  mul_ans_size=w_info_size;
                  for(int i=0;i<w_info_size;i++){
                    do{
                      poll_fd[1].fd=socket(worker_info[i].addr.sin_family,SOCK_STREAM,0);
                    }while(poll_fd[1].fd==-1);
          // printf("---------CONNECTING WITH WORKER\n");

                    if(connect(poll_fd[1].fd,(struct sockaddr *)&worker_info[i].addr,sizeof(worker_info[i].addr))<0){
                      perror("\033[1m\033[31m\t-Handshake failed-[WORKER MAY BE DEAD]\033[0m");
                      dead_fd_flag=1;
                    }
        // printf("-----------CONNECTED-----------!\n");
                    mul_ans_fd[i].fd=poll_fd[1].fd;
                    if(safe_write(poll_fd[1].fd,(uint8_t *)&len,sizeof(int))==-1){//how many bytes
                      // perror("write fail line 388");
                      dead_fd_flag=1;
                      something_happened=1;
                      break;
                    }
                    if(safe_write(poll_fd[1].fd,(uint8_t *)&user_ch,sizeof(enum worker_operations))==-1){//which operation
                      // perror("write fail 396");
                      dead_fd_flag=1;
                      something_happened=1;
                    }
                    if(safe_write(poll_fd[1].fd,(uint8_t *)(user_input+strlen(user_choice)+1),len)==-1){//the message
                      // perror("write fail 404");
                      dead_fd_flag=1;
                      something_happened=1;
                    }
                  }
                  if(!dead_fd_flag)
                    SUCCESS++;
                  else{
                    FAIL++;
                    printf("\033[1m\033[31m\t An error occured [%s]\033[0m\n",user_input);
                    shutdown(poll_fd[0].fd,SHUT_RDWR);//end the connection with client
                    close(poll_fd[0].fd);//close the descriptor
                  }
                }else{//inform process that deals with the country given
                  c_flag=0;
                  for(int i=0;i<w_info_size;i++)
                    for(int j=0;j<worker_info[i].c_size;j++)
                      if(!strcmp(worker_info[i].countries[j],countr_name)){
                        c_flag=1;
                        do{
                          mul_ans_fd=malloc(1*sizeof(struct pollfd));
                        }while(mul_ans_fd==NULL);
                        do{
                          poll_fd[1].fd=socket(worker_info[i].addr.sin_family,SOCK_STREAM,0);
                        }while(poll_fd[1].fd==-1);
                        mul_ans_fd[0].fd=poll_fd[1].fd;
                        mul_ans_fd[0].events=POLLIN;
                        mul_ans_size=1;
              // printf("---------CONNECTING WITH WORKER\n");

                        if(connect(poll_fd[1].fd,(struct sockaddr *)&worker_info[i].addr,sizeof(worker_info[i].addr))<0){
                          perror("\033[1m\033[31m\t-Handshake failed-[WORKER MAY BE DEAD]\033[0m");
                        }

            // printf("Connected with worker!\n");
                        if(safe_write(poll_fd[1].fd,(uint8_t *)&len,sizeof(int))==-1){//how many bytes
                          dead_fd_flag=1;
                          // perror("write fail line 448");
                          something_happened=1;
                        }
                        if(safe_write(poll_fd[1].fd,(uint8_t *)&user_ch,sizeof(enum worker_operations))==-1){//which operation
                          dead_fd_flag=1;
                          // perror("write fail line 456");
                          something_happened=1;
                        }
                        if(safe_write(poll_fd[1].fd,(uint8_t *)(user_input+strlen(user_choice)+1),len)==-1){//the message
                          dead_fd_flag=1;
                          // perror("write fail line 465");
                          something_happened=1;
                        }
                      }
            // printf("Wrote to worker!!\n");
                  if(c_flag==0){
                    something_happened=1;
                    FAIL++;
                  }else if(dead_fd_flag==1){
                    printf("\033[1m\033[31m\t An error occured [%s]\033[0m\n",user_input);
                    shutdown(poll_fd[0].fd,SHUT_WR);//end the connection with client
                    close(poll_fd[0].fd);//close the descriptor
                    FAIL++;
                  }else{
                    SUCCESS++;
                  }
                }
                break;
            }
            //NOW ITS TIME TO GET THE ANSWERS FROM WORKERS AND FORWARD THEM TO CLIENT
            if(something_happened){//while trying to write to worker
              if(user_ch==TOPK_AGERANGES|| user_ch==DISEASE_FREQUENCY || user_ch==NUMPADMISSIONS || user_ch==NUMPDISCHARGES)
                if(c_flag==0){//means that there is no such country and client must know
                  output_len+=sprintf(output,"%s\n",user_input);
                  output_len+=sprintf(output+output_len,"No such country!\n");
                  safe_write(poll_fd[0].fd,(uint8_t *)output,output_len);//tell him whats wrong
              // printf("WROTE TO CLIENT\n");
                  shutdown(poll_fd[0].fd,SHUT_WR);//end the connection with client
                  close(poll_fd[0].fd);//close the descriptor
                }
            }else{//SUCCESFULLY INFORMED WORKER AND NOW I HAVE TO READ THE RESULT AND SEND IT TO CLIENT
              output_len+=sprintf(output,"%s\n",user_input);
              int found_patient=0;
              int freq_no_country=0;
              for(int i=0;i<mul_ans_size;i++){
                fcntl(mul_ans_fd[i].fd, F_SETFL, fcntl(mul_ans_fd[i].fd, F_GETFL, 0) | O_NONBLOCK);//set fd non_block
                for(int timeouts=0;timeouts<2;timeouts++){//in 2 continous timeouts im outta here
                  ret_val=poll(mul_ans_fd+i,(unsigned long)1,65);
                  if(ret_val<0){//signal interrupt

                  }else if(!ret_val)
                    continue;
              // printf("READING ANSWER\n");
                  if((mul_ans_fd[i].revents&POLLIN)==POLLIN){//means that i got the answer
                    bytes=(int *)pipe_read(mul_ans_fd[i].fd,(uint8_t *)read_buffer,buffersize,sizeof(int));
                    if(bytes==NULL){//means something happend to the other end while trying to read (worker may have died)
                      FAIL++;
                      // perror("read fail line 527");
                      break;
                    }
                    op_read=(enum worker_operations *)pipe_read(mul_ans_fd[i].fd,(uint8_t *)read_buffer,buffersize,sizeof(enum worker_operations));

                    if(op_read==NULL){//means something happend to the other end while trying to read(worker may have died)
                      FAIL++;
                      // perror("read fail");
                      break;
                    }
                    switch (*op_read){
                      case DISEASE_FREQUENCY:
                        timeouts--;
                        free(op_read);
                        bytes_to_read=*bytes;
                        free(bytes);
                        if(bytes_to_read>sizeof(int)){//means that this answer is for a particular country of worker
                          data=(uint8_t *)pipe_read(mul_ans_fd[i].fd,(uint8_t *)read_buffer,buffersize,bytes_to_read);//the disease itself
                          if(data==NULL){
                            FAIL++;
                            break;
                          }
                          output_len+=sprintf(output+output_len,"%d cases in %s [diseaseFrequency]\n",*data,data+sizeof(int));
                        }else{//there is only one int which need to be summe1d with the others
                          freq_no_country=1;
                          data=(uint8_t *)pipe_read(mul_ans_fd[i].fd,(uint8_t *)read_buffer,buffersize,sizeof(int));
                          if(data==NULL){
                            FAIL++;
                          }

                          counter++;
                          freq_sum+=*data;

                          if(counter==w_info_size){//if all workers have answered to this particular question
                            counter=0;

                            output_len+=sprintf(output+output_len,"%d\n",freq_sum);
                            freq_sum=0;//initialize again
                          }

                        }
                        free(data);

                        break;

                      case TOPK_AGERANGES:
                        timeouts--;

                        free(op_read);
                        int whole_msg_size=*bytes;
                        free(bytes);

                        bytes=(int *)pipe_read(mul_ans_fd[i].fd,(uint8_t *)read_buffer,buffersize,sizeof(int));//how many categories
                        data=(uint8_t *)pipe_read(mul_ans_fd[i].fd,(uint8_t *)read_buffer,buffersize,whole_msg_size);
                        if(bytes==NULL || data==NULL){//means something happend to the other end while trying to read
                          FAIL++;
                          // perror("read fail line 542");
                          break;
                        }
                        get_topk_from_raw_data(rec_array,data,*bytes);//get all the categories


                        for(int m=0;m<(*bytes)-1;m++){
                          output_len+=sprintf(output+output_len,"%s: %.1f\n",rec_array[m].category,(float)rec_array[m].counter/rec_array[*bytes-1].counter*100);
                        }
                        for(int m=0;m<(*bytes);m++)
                          destroy_topk(&rec_array[m]);

                        free(bytes);
                        free(data);
                        break;
                      case NUMPADMISSIONS:
                      case NUMPDISCHARGES:
                        free(op_read);
                        bytes_to_read=*bytes;
                        free(bytes);
                        data=(uint8_t *)pipe_read(mul_ans_fd[i].fd,(uint8_t *)read_buffer,buffersize,bytes_to_read);//get the whole message(1 country at a time)
                        if(data==NULL){
                          // perror("read fail line 568");
                          FAIL++;
                          break;
                        }
                  printf("%s %d\n",data,*(data+strlen(data)+1));
                        output_len+=sprintf(output+output_len,"%s %d\n",data,*(data+strlen(data)+1));
                        free(data);
                        timeouts--;
                        break;
                      case SEARCH_PATIENT:
                        timeouts--;
                        free(op_read);
                        if(*bytes==0){
                          free(bytes);
                          break;
                        }
                        found_patient=1;
                        //an answer means that someone found the patient we were looking for
                        output_len+=sprintf(output+output_len,"\t");
                        for(int j=0;j<4;j++){//contains: id name surname age entry exit (#6)
                          bytes=(int *)pipe_read(mul_ans_fd[i].fd,(uint8_t *)read_buffer,buffersize,sizeof(int));
                          data=(uint8_t *)pipe_read(mul_ans_fd[i].fd,(uint8_t *)read_buffer,buffersize,*bytes);
                          if(bytes==NULL || data==NULL)//means something happend to the other end while trying to read
                            break;
                          free(bytes);
                          output_len+=sprintf(output+output_len,"%s ",data);
                          free(data);
                        }
                        bytes=(int *)pipe_read(mul_ans_fd[i].fd,(uint8_t *)read_buffer,buffersize,sizeof(int));//this is the age
                        if(bytes==NULL){
                          // perror("read fail line 598");

                          FAIL++;
                          break;
                        }
                        output_len+=sprintf(output+output_len,"%d ",*bytes);
                        free(bytes);
                        for(int j=4;j<6;j++){
                          bytes=(int *)pipe_read(mul_ans_fd[i].fd,(uint8_t *)read_buffer,buffersize,sizeof(int));
                          data=(uint8_t *)pipe_read(mul_ans_fd[i].fd,(uint8_t *)read_buffer,buffersize,*bytes);
                          if(bytes==NULL || data==NULL)//means something happend to the other end while trying to read
                            break;
                          free(bytes);
                          output_len+=sprintf(output+output_len,"%s ",data);
                          free(data);
                        }
                        if(bytes==NULL || data==NULL){//means something happend to the other end while trying to read
                          // perror("read fail line 613");
                          FAIL++;
                          break;
                        }
                        output_len+=sprintf(output+output_len,"\n");

                        break;
                    }
                  }

                }
              }
              for(int i=0;i<mul_ans_size;i++){
                shutdown(mul_ans_fd[i].fd,SHUT_RDWR);//end the connection with worker
                close(mul_ans_fd[i].fd);//close the descriptor
              }
              if(user_ch==SEARCH_PATIENT&&found_patient==0)
                output_len+=sprintf(output+output_len,"No such patient!\n");

              safe_write(0,(uint8_t *)output,output_len);//print to stdout
              safe_write(poll_fd[0].fd,(uint8_t *)output,output_len);//forward to client
              shutdown(poll_fd[0].fd,SHUT_WR);//end the connection with client
              close(poll_fd[0].fd);//close the descriptor
              free(mul_ans_fd);
            }
            break;
        }
    }

  }


}

int main(int argc,char **argv){
  if(argc!=9){
    printf("Error wrong use\n");//funct needed here for right use
    exit(1);
  }
  static struct sigaction act;
  act.sa_handler=my_handler;
  sigfillset(&act.sa_mask);
  sigaction(SIGPIPE,&act,NULL);//the default action is TERMINATE THIS PROCESS-->WE DONT WANT THAT!!
  sem_init(&notif_sem_main_thread,0,0);//second argument is for semaphore to be shared between threads of the process
  if(pthread_mutex_init(&con_with_worker_mutex,NULL)!=0){
    perror("mutex init has failed\n");
    return 1;
  }
  if(pthread_mutex_init(&buffer_mutex,NULL)!=0){
    perror("mutex init has failed\n");
    return 1;
  }
  if(pthread_mutex_init(&worker_info_mutex,NULL)!=0){
    perror("mutex init has failed\n");
    return 1;
  }
  int flag[4]={0};
  int buffersize,ans_port,query_port;
  int thread_number;

  for(int i=0;i<4;i++){
    if(!flag[0] && !strcmp(argv[2*i+1],"-q")){
      query_port=atoi(argv[2*i+2]);
      flag[0]=1;
    }else if(!flag[1] && !strcmp(argv[2*i+1],"-b")){
      buffersize=atoi(argv[2*i+2]);
      if(buffersize==0){
        printf("Buffersize can't be 0\n");
        exit(1);
      }
      flag[1]=1;
    }else if(!flag[2] && !strcmp(argv[2*i+1],"-s")){
      ans_port=atoi(argv[2*i+2]);
      flag[2]=1;
    }else if(!flag[3] && !strcmp(argv[2*i+1],"-w")){
      thread_number=atoi(argv[2*i+2]);
      flag[3]=1;
    }else{
      printf("Error wrong parameters\n");//funct needed
      exit(1);
    }
  }
  if(thread_number==0){
    printf("Thread number can't be 0\n");
    exit(1);
  }
  int ans_fd,query_fd;
  do{
    ans_fd=socket(AF_INET,SOCK_STREAM,0);
  }while(ans_fd<0);
  do{
    query_fd=socket(AF_INET,SOCK_STREAM,0);
  }while(query_fd<0);
  sockaddr_in server_addr_ans,server_addr_query;
  server_addr_ans.sin_family=AF_INET;
  server_addr_ans.sin_addr.s_addr=htonl(INADDR_ANY);
  server_addr_ans.sin_port=htons(ans_port);

  if(setsockopt(ans_fd, SOL_SOCKET, SO_REUSEADDR,&TM_WAIT, sizeof(int))){
    perror("setsockopt ans_fd");
    exit(1);
  }

  server_addr_query.sin_family=AF_INET;
  server_addr_query.sin_addr.s_addr=htonl(INADDR_ANY);
  server_addr_query.sin_port=htons(query_port);
  if(setsockopt(query_fd, SOL_SOCKET, SO_REUSEADDR,&TM_WAIT, sizeof(int))){
        perror("setsockopt query_fd");
        exit(1);
  }
  if(bind(ans_fd, (sockaddr *)&server_addr_ans,sizeof(server_addr_ans))<0){
        perror("bind failed for ans_fd");
        exit(1);
  }
  if(bind(query_fd, (sockaddr *)&server_addr_query,sizeof(server_addr_query))<0){
        perror("bind failed for query_fd");
        exit(1);
  }
  if(listen(ans_fd,100)<0){//workers are max 43 so 100 is moree than fine
    perror("listen ans_fd");
    exit(1);
  }
  if(listen(query_fd,100000)<0){//thread_number gonna access server for queries at the same time
    perror("listen query_fd");
    exit(1);
  }
  pthread_t * thread_array;
  Circular_buffer * circ_buffer=buff_alloc();
  buff_init(circ_buffer,buffersize);
  do{
    thread_array=malloc(thread_number*sizeof(pthread_t));
  }while(thread_array==NULL);

  for(int i=0;i<thread_number;i++)
    pthread_create(&thread_array[i],NULL,server_thread,(void *)circ_buffer);//creating threads with argument the malloced pointer of circ buffer*/

  struct pollfd poll_fd[2];//one for the fd that workers write the answers to the queries and one for the queries clients write
  //0 is for clients,1 is for workers
  poll_fd[0].fd=query_fd;
  poll_fd[0].events=POLLIN;
  poll_fd[1].fd=ans_fd;
  poll_fd[1].events=POLLIN;
  int ret_val;
  int timeout_detected=-1;
  int accept_fd;
  uint8_t read_buffer[100];
  enum thr_work op;
  printf("\033[1m\033[32mWaiting for connections!\033[0m\n");
  while(1){
    do{
      ret_val=poll(&poll_fd[1],(unsigned long)1,80);
      if(ret_val<0){//something happened with signals

      }else if(ret_val!=0){//if not timedout
        accept_fd=accept(poll_fd[1].fd,NULL,NULL);//don't care who he is
        //need to get the port num inside thread when reading MY_INFO operation
        op=GET_WORKER_STATS;

        while(buff_full(circ_buffer))//if buffer is full wait until notified
          sem_wait(&notif_sem_main_thread);

        //woke up or was already asleep
        pthread_mutex_lock(&buffer_mutex);//acquire lock to add element to circular buffer
        buff_add(circ_buffer,accept_fd,op);
        if(get_cur_size(circ_buffer)==1)
          pthread_cond_broadcast(&thread_cond);
        pthread_mutex_unlock(&buffer_mutex);//release lock --> exiting critical section
        continue;//check again
      }else
        timeout_detected++;
    }while(timeout_detected<=0);//we need to empty the ans_fd and make sure we got the MY_INFO operation from all workers
                              //so i suppose that after 2 timeouts all the workers must have sent their info
    timeout_detected=0;
  //now its time for checking client reequests;


    ret_val=poll(&poll_fd[0],(unsigned long)1,80);
    if(ret_val<0){//signal interrupt maybe

    }else if(ret_val!=0){//if data appeared for reading

      accept_fd=accept(poll_fd[0].fd,NULL,NULL);//don't care who he is,because thread will find out and handle
      op=GET_CLIENT_REQUEST;
      while(buff_full(circ_buffer)){//if buffer is full wait until notified
  // printf("***********--SLEEPING--**************\n");
        sem_wait(&notif_sem_main_thread);
    // printf("***********--WOKE-UP--**************\n");
      }
      // printf("------------------------%d\n",get_cur_size(circ_buffer));
        //woke up or was already asleep
      pthread_mutex_lock(&buffer_mutex);//acquire lock to add element to circular buffer
      buff_add(circ_buffer,accept_fd,op);
      if(get_cur_size(circ_buffer)==1)
        pthread_cond_broadcast(&thread_cond);
      pthread_mutex_unlock(&buffer_mutex);//release lock --> exiting critical section
    }
  }
  return 0;
}
