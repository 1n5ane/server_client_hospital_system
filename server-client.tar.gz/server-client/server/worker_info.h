#ifndef __WORKER_INFO_H__
#define __WORKER_INFO_H__
#include <netinet/in.h>
typedef struct worker_info{
  char ** countries;//which countries
  int c_size;//size of countries array
  struct sockaddr_in addr;
}Worker_info;
#endif
