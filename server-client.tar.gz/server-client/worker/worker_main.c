#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <dirent.h>
#include <time.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <semaphore.h>
#include <sys/socket.h>
#include <poll.h>
#include "System/system.h"
#include "../safe_io.h"

enum worker_operations{SUMMARY_STATS,DISEASE_FREQUENCY,TOPK_AGERANGES,SEARCH_PATIENT,NUMPADMISSIONS,NUMPDISCHARGES,MY_INFO};
typedef struct sockaddr_in sockaddr_in;
typedef struct in_addr in_addr;
typedef struct sockaddr sockaddr;
int ans_count=0;
int TM_WAIT=0;
struct linger so_linger;
int SIGINT_COUNTER=0;
int SIGUSR1_COUNTER=0;
int SUCCESS=0;
int FAIL=0;
extern int BUCKET_SIZE;

int DISEASE_HT_SIZE=13;
int COUNTRY_HT_SIZE=13;

int IM_LAST_WORKER=0;

void my_handler(int signo){
  if(signo==SIGINT || signo==SIGQUIT){
    SIGINT_COUNTER++;
  }
  else if(signo==SIGUSR1)
    SIGUSR1_COUNTER++;
  else if(signo==SIGUSR2)//only last worker will receive SIGUSR2
    IM_LAST_WORKER=1;
  else if(signo==SIGPIPE);
    // printf("GOOOT A SIGPIPE!!!\n");
}

int main(int argc,char ** argv){//first parameter is id ->[1-N] and second is buffersize
  static struct sigaction act;
  act.sa_handler=my_handler;
  sigfillset(&act.sa_mask);
  sigaction(SIGUSR2,&act,NULL);
  sigaction(SIGCONT,&act,NULL);
  so_linger.l_onoff=1;
  so_linger.l_linger=0;
  int SIGINT_PREV_VAL=0;
  int SIGUSR1_PREV_VAL=0;
  int worker_id=atoi(argv[1]);
  pid_t pid=getpid();
  char * read_buffer=NULL;
  int prev_con_fd=-1;
  int buffersize=atoi(argv[2]);
  // printf("Im worker %d with pid %ld\n",worker_id,(long int)pid);
  char rpipe[50];
  strcpy(rpipe,"../pipefiles/rpipe");
  sprintf(rpipe+strlen(rpipe),"%d",worker_id);

  int read_pipe_fd=open(rpipe,O_RDONLY|O_NONBLOCK);
  if(read_pipe_fd<0){
    printf("worker_id %d and pid %ld\n",worker_id,(long int)pid);
    perror("read_pipe");
    exit(1);
  }
  int write_pipe_fd;

  read_buffer=malloc(buffersize);
  if(read_buffer==NULL){
    printf("Malloc error in buffer!\n");
    close(read_pipe_fd);
    close(write_pipe_fd);
    exit(1);
  }
  uint8_t * data;
  struct pollfd poll_fd[2];//2 fds one for reading and one for writing
  int retval;
  int *msg_size;
  enum worker_operations * op;
  poll_fd[0].fd=read_pipe_fd;
  poll_fd[0].events=POLLIN;
  poll_fd[1].events=POLLOUT;

  sigaction(SIGUSR1,&act,NULL);
  sigaction(SIGPIPE,&act,NULL);

   sigaction(SIGINT,&act,NULL);
   sigaction(SIGQUIT,&act,NULL);

  char **country_path;
  int countries;//size of country_path
  char **country_name;
  System s;
  DIR * dir;
  struct stat dir_info;
  struct dirent * entry;
  int date_file_fd;
  char file_path[60];
  system_init(&s,DISEASE_HT_SIZE,COUNTRY_HT_SIZE,BUCKET_SIZE);
  char virus[50];
  char date1[20];
  char date2[20];
  char country[50];
  struct tm * modification_time;
  char ***dates_str;//dates_str[0][0] first file_name of first country ,dates_str[0][1] second filename of firs country etc...
  int * dir_files;//dir_files[0]-->how many files has the first country etc....
  int mes_size;
  int count;
  int ip_len;
  char * server_ip_str;
  int server_port;
  int its_over=0;
  sockaddr_in server_sock;
  server_sock.sin_family=AF_INET;
  sockaddr_in query_sock;
  query_sock.sin_family=AF_INET;
  sem_t * mutex_sem=sem_open("/w_sem",O_WRONLY);
  sem_t * workers_sync=sem_open("/s_sem",O_WRONLY);
  sem_t * worker_notif=sem_open("/n_sem",O_WRONLY);

  while(!its_over){
    retval=poll(poll_fd,(unsigned long)1,-1);//block forever until something is available
    if(retval<0)
      continue;
    its_over=1;
  }

  if((poll_fd[0].revents&POLLIN) == POLLIN){//if data appears on read_pipe
    msg_size=(int *)pipe_read(poll_fd[0].fd,(uint8_t *)read_buffer,buffersize,sizeof(int));
    op=(enum worker_operations *)pipe_read(poll_fd[0].fd,read_buffer,buffersize,sizeof(enum worker_operations));
      switch(*op){
        case  SUMMARY_STATS:
              free(op);
              countries=*msg_size;
              do{
                country_path=malloc(countries*sizeof(char*));//hold the paths
              }while(country_path==NULL);
              do{
                modification_time=malloc(countries*sizeof(struct tm));
              }while(modification_time==NULL);
              do{
                country_name=malloc(countries*sizeof(char*));//holds the names
              }while(country_name==NULL);

              free(msg_size);
              for(int i=0;i<countries;i++){
                msg_size=(int *)pipe_read(poll_fd[0].fd,(uint8_t *)read_buffer,buffersize,sizeof(int));
                data=pipe_read(poll_fd[0].fd,(uint8_t *)read_buffer,buffersize,*msg_size);

                do{
                  country_path[i]=malloc(strlen(data)+1);
                }while(country_path[i]==NULL);
                strcpy(country_path[i],data);
                get_country_name(&country_name[i],country_path[i]);
                //open dir and read all the files and then send the summary stats via named pipe
                free(data);
                free(msg_size);
              }

              msg_size=(int *)pipe_read(poll_fd[0].fd,(uint8_t *)read_buffer,buffersize,sizeof(int));//len of ip string
              ip_len=*msg_size;
              free(msg_size);
              server_ip_str=(char *)pipe_read(poll_fd[0].fd,(uint8_t *)read_buffer,buffersize,ip_len);//the ip
              msg_size=(int *)pipe_read(poll_fd[0].fd,(uint8_t *)read_buffer,buffersize,sizeof(int));//the port
              server_port=*((int*)msg_size);
              free(msg_size);
              if(!inet_aton(server_ip_str,&server_sock.sin_addr)){
                printf("Invalid server ip\n");
                exit(1);
              }


              server_sock.sin_port=htons(server_port);//same
              query_sock.sin_addr.s_addr=htonl(INADDR_ANY);
              query_sock.sin_port=0;
              do{
                poll_fd[1].fd=socket(server_sock.sin_family,SOCK_STREAM,0);
              }while(poll_fd[1].fd==-1);
              close(poll_fd[0].fd);//close the named pipe because not needed
              do{
                poll_fd[0].fd=socket(query_sock.sin_family,SOCK_STREAM,0);
              }while(poll_fd[0].fd==-1);
              //finished reading from pipe --> now time to chage poll_fd[0] to socket fd in a port to listen from now on to requests
              setsockopt(poll_fd[0].fd,SOL_SOCKET,SO_REUSEADDR,&TM_WAIT,sizeof(int));//to avoid waiting ->usefull for debugging
              if(bind(poll_fd[0].fd,(sockaddr *)&query_sock,sizeof(sockaddr_in))<0){
                perror("\033[1m\033[31mBind failed\033[0m");
                exit(1);
              }
              socklen_t s_len=sizeof(query_sock);
              if(getsockname(poll_fd[0].fd,(sockaddr *)&query_sock,&s_len)<0){
                perror("Getsockname error");
                exit(1);
              }

              //query_sock.sin_port contains port in network byte order

           //do tcp handshakes
             while(connect(poll_fd[1].fd,(sockaddr *)&server_sock,sizeof(server_sock))<0){
               perror("\033[1m\033[31m-Handshake failed-\033[0m");
               sleep(2);
             }
             printf("\033[1m\033[32m\tSuccessfully connected to server! [Worker %d]\033[0m\n",worker_id);
             enum worker_operations w_op=MY_INFO;

             safe_write(poll_fd[1].fd,(uint8_t *)&worker_id,sizeof(int));//AT FIRST WRITE YOUR ID (0-(N-1))
             safe_write(poll_fd[1].fd,(uint8_t *)&w_op,sizeof(enum worker_operations));//THEN WHICH OPERATION -> MY_INFO
             safe_write(poll_fd[1].fd,(uint8_t *)&countries,sizeof(int));//THEN HOW MANY COUNTRIES
      // printf("PORT %d\n",ntohs(query_sock.sin_port));

             safe_write(poll_fd[1].fd,(uint8_t *)&query_sock.sin_port,sizeof(unsigned short));//THEN the port


             for(int j=0;j<countries;j++){
               int c_len=strlen(country_name[j])+1;
               safe_write(poll_fd[1].fd,(uint8_t *)&c_len,sizeof(int));//len of country str
               safe_write(poll_fd[1].fd,(uint8_t *)country_name[j],c_len);//country str
             }
             int sem_val;
             sem_wait(mutex_sem);
             sem_getvalue(workers_sync,&sem_val);

             if(sem_val==0){//means that i musnt wait on semaphore and inform parent im the last to wake up all the brothers that are paused
               kill(getppid(),SIGUSR2);
               // printf("Im last! %d\n",worker_id);
               sem_post(mutex_sem);
             }else{//IF NOT LAST PROCESS DECREASE SEMAPHORE AND PAUSE UNTIL WOKEN UP BY PARENT
               sem_wait(workers_sync);
               sem_post(mutex_sem);
               sem_wait(worker_notif);//sleep until woken up by parent
             }
              w_op=SUMMARY_STATS;
              int files_in_dir;
              do{
                dates_str=malloc(countries*sizeof(char **));
              }while(dates_str==NULL);
              do{
                dir_files=malloc(countries*sizeof(int));
              }while(dir_files==NULL);

              for(int i=0;i<countries;i++){
                do{
                  dir=opendir(country_path[i]);
                }while(dir==NULL);

                stat(country_path[i],&dir_info);
                files_in_dir=0;
                modification_time[i]=*(gmtime(&dir_info.st_mtime));//get modification time of i dir

                while((entry=readdir(dir))!=NULL)
                  files_in_dir++;//files in dir also counted . and ..
                rewinddir(dir);
                dir_files[i]=files_in_dir-2;
                strcpy(file_path,country_path[i]);
                int len=strlen(file_path);
                if(file_path[len-1]!='/'){
                  strcat(file_path,"/");
                  len++;
                }
                int k=0;
                do{
                  dates_str[i]=malloc((files_in_dir-2)*sizeof(char *));
                }while(dates_str[i]==NULL);

                for(int j=0;j<files_in_dir;j++){
                  entry=readdir(dir);
                  if(!strcmp(entry->d_name,"..") || !strcmp(entry->d_name,"."))
                    continue;
                  do{
                    dates_str[i][k]=malloc(strlen(entry->d_name)+1);
                  }while(dates_str[i][k]==NULL);
                  strcpy(dates_str[i][k],entry->d_name);
                  k++;
                }
                date_sort(dates_str[i],files_in_dir-2);
                char ** diseases_found;
                int disease_size;
                Topk_ages_rec * cases_array;
                for(int j=0;j<files_in_dir-2;j++){
                  sprintf(file_path+len,"%s",dates_str[i][j]);

                  input_from_file(&s,file_path,country_name[i],dates_str[i][j],&diseases_found,&disease_size);//input record from file to system
                  shutdown(poll_fd[1].fd,SHUT_WR);
                  close(poll_fd[1].fd);
                  do{
                    poll_fd[1].fd=socket(server_sock.sin_family,SOCK_STREAM,0);
                  }while(poll_fd[1].fd==-1);
                  while(connect(poll_fd[1].fd,(sockaddr *)&server_sock,sizeof(server_sock))<0){
                    perror("\033[1m\033[31m\t-Handshake failed-\033[0m");
                    sleep(2);
                  }
                  safe_write(poll_fd[1].fd,(uint8_t *)&disease_size,sizeof(int));//at first how many diseases
                  safe_write(poll_fd[1].fd,(uint8_t *)&w_op,sizeof(enum worker_operations));//which operation
                  int date_len=strlen(dates_str[i][j])+1;
                  safe_write(poll_fd[1].fd,(uint8_t *)&date_len,sizeof(int));//how big is the date
                  safe_write(poll_fd[1].fd,(uint8_t *)dates_str[i][j],date_len);//the date
                  date_len=strlen(country_name[i])+1;
                  safe_write(poll_fd[1].fd,(uint8_t *)&date_len,sizeof(int));//how big is the country
                  safe_write(poll_fd[1].fd,(uint8_t *)country_name[i],date_len);//the country

                  for(int l=0;l<disease_size;l++){
                    int d_len=strlen(diseases_found[l])+1;

                    cases_array=topk_AgeRanges(&s,4,country_name[i],diseases_found[l],dates_str[i][j],dates_str[i][j],SUMMARY_STATS);
                    if(cases_array==NULL){
                      printf("fuuuck\n");
                    }else{
                      safe_write(poll_fd[1].fd,(uint8_t *)&d_len,sizeof(int));//how big is the disease
                      safe_write(poll_fd[1].fd,(uint8_t *)diseases_found[l],d_len);//the disease
                      // printf("Ok wrote %d %s\n",*(&d_len),diseases_found[l]);
                      int whole_message=8*sizeof(int);
                      int cat_len[4];
                      for(int m=0;m<4;m++){
                        cat_len[m]=strlen(cases_array[m].category)+1;
                        whole_message+=cat_len[m];
                      }
                      safe_write(poll_fd[1].fd,(uint8_t *)&whole_message,sizeof(int));
                      for(int m=0;m<4;m++){
                        safe_write(poll_fd[1].fd,(uint8_t *)(&cat_len[m]),sizeof(int));//write len of category (age category)
                        safe_write(poll_fd[1].fd,(uint8_t *)(cases_array[m].category),cat_len[m]);//write the category
                        safe_write(poll_fd[1].fd,(uint8_t *)(&cases_array[m].counter),sizeof(int));//write the counter
                        destroy_topk(&cases_array[m]);
                      }
                      destroy_topk(&cases_array[4]);//the all info
                      free(cases_array);
                    }
                  }

                  if(disease_size!=0){
                    for(int l=0;l<disease_size;l++)
                      free(diseases_found[l]);
                    free(diseases_found);
                  }
                  shutdown(poll_fd[1].fd,SHUT_WR);
                  close(poll_fd[1].fd);
                }
              }
              printf("\033[32mSuccessfully sent the summary stats! [Worker %d]\033[0m\n",worker_id);
              SUCCESS++;//successfull answered summary stats
              break;

      }
      //SAME CODE AS THE CODE WHEN THE POLL IS INTERRUPTED BY A SIGNAL-->A SIGNAL CAN ALSO OCCUR WHEN PROCESSING A REQUEST
      if(SIGINT_PREV_VAL<SIGINT_COUNTER){
        //if got SIGINT or SIGQUIT
        strcpy(file_path,"../logfiles/log_file.");
        sprintf(file_path+strlen(file_path),"%ld",(long int)getpid());

        int log_fd=open(file_path,O_CREAT|O_WRONLY,0777);

        if(log_fd<0){
          printf("[%ld]\n",(long int)getpid());
          perror("Child log file");
        }else{
          for(int i=0;i<countries;i++)
            dprintf(log_fd,"%s\n",country_name[i]);
          dprintf(log_fd,"TOTAL %d\n",SUCCESS+FAIL);
          dprintf(log_fd,"SUCCESS %d\n",SUCCESS);
          dprintf(log_fd,"FAIL %d\n",FAIL);

          close(log_fd);
        }
        SIGINT_PREV_VAL=SIGINT_COUNTER;
      }else if(SIGUSR1_PREV_VAL<SIGUSR1_COUNTER){//got a SIGUSR1 and got to check the dir for new files
        SIGUSR1_PREV_VAL=SIGUSR1_COUNTER;
        struct tm current_mod_time;
        time_t t1,t2;
        struct stat file_info;

        int new_in_dir;//new in dir count new files
        char **new_date;//dates_str hold the name of new files
                        //because we need to sort them and open them in increasing order
        int found;
        for(int i=0;i<countries;i++){
          new_in_dir=0;
          // printf("%s\n",country_path[i]);
          stat(country_path[i],&dir_info);
          current_mod_time=*(gmtime(&dir_info.st_mtime));
          t1=mktime(&modification_time[i]);//contains last mod time
          t2=mktime(&current_mod_time);//contains current mod time
          if(difftime(t1,t2)<0){//means that dir has new files or user modified an existing file
            do{
              dir=opendir(country_path[i]);//open the dir
            }while(dir==NULL);
            strcpy(file_path,country_path[i]);
            mes_size=strlen(country_path[i]);
            while((entry=readdir(dir))!=NULL){
              found=0;
              if(!strcmp(entry->d_name,"..") || !strcmp(entry->d_name,"."))
                continue;

              for(int l=0;l<dir_files[i];l++)
                if(!strcmp(entry->d_name,dates_str[i][l])){
                  found=1;
                  break;
                }
              if(!found){
                new_in_dir++;//files in dir indicates new files
                if(new_in_dir==1){//malloc()
                  do{
                    new_date=malloc(sizeof(char *));
                  }while(new_date==NULL);
                  do{
                    new_date[0]=malloc(strlen(entry->d_name)+1);
                  }while(new_date[0]==NULL);
                  strcpy(new_date[0],entry->d_name);
                }else{//realloc()
                  do{
                    new_date=realloc(new_date,new_in_dir*sizeof(char*));
                  }while(new_date==NULL);
                  do{
                    new_date[new_in_dir-1]=malloc(strlen(entry->d_name)+1);
                  }while(new_date[new_in_dir-1]==NULL);
                  strcpy(new_date[new_in_dir-1],entry->d_name);
                }
              }
            }
            date_sort(new_date,new_in_dir);
            char ** diseases_found;
            int disease_size=0;
            Topk_ages_rec * cases_array;

            strcat(file_path,"/");
            enum worker_operations w_op=SUMMARY_STATS;
            for(int j=0;j<new_in_dir;j++){
              sprintf(file_path+mes_size+1,"%s",new_date[j]);

              input_from_file(&s,file_path,country_name[i],new_date[j],&diseases_found,&disease_size);//input record from file to system
              do{
                poll_fd[1].fd=socket(server_sock.sin_family,SOCK_STREAM,0);
              }while(poll_fd[1].fd==-1);
              while(connect(poll_fd[1].fd,(sockaddr *)&server_sock,sizeof(server_sock))<0){
                perror("\033[1m\033[31m\t-Handshake failed-\033[0m");
                sleep(1);
              }
              safe_write(poll_fd[1].fd,(uint8_t *)&disease_size,sizeof(int));//at first how many diseases
              safe_write(poll_fd[1].fd,(uint8_t *)&w_op,sizeof(enum worker_operations));//which operation
              int date_len=strlen(new_date[j])+1;
              safe_write(poll_fd[1].fd,(uint8_t *)&date_len,sizeof(int));//how big is the date
              safe_write(poll_fd[1].fd,(uint8_t *)new_date[j],date_len);//the date
              date_len=strlen(country_name[i])+1;
              safe_write(poll_fd[1].fd,(uint8_t *)&date_len,sizeof(int));//how big is the country
              safe_write(poll_fd[1].fd,(uint8_t *)country_name[i],date_len);//the country

              for(int l=0;l<disease_size;l++){
                int d_len=strlen(diseases_found[l])+1;

                cases_array=topk_AgeRanges(&s,4,country_name[i],diseases_found[l],new_date[j],new_date[j],SUMMARY_STATS);
                if(cases_array==NULL){
                  printf("fuuuck\n");
                }else{
                  safe_write(poll_fd[1].fd,(uint8_t *)&d_len,sizeof(int));//how big is the disease
                  safe_write(poll_fd[1].fd,(uint8_t *)diseases_found[l],d_len);//the disease
                  // printf("Ok wrote %d %s\n",*(&d_len),diseases_found[l]);
                  int whole_message=8*sizeof(int);
                  int cat_len[4];
                  for(int m=0;m<4;m++){
                    cat_len[m]=strlen(cases_array[m].category)+1;
                    whole_message+=cat_len[m];
                  }
                  safe_write(poll_fd[1].fd,(uint8_t *)&whole_message,sizeof(int));
                  for(int m=0;m<4;m++){
                    safe_write(poll_fd[1].fd,(uint8_t *)(&cat_len[m]),sizeof(int));//write len of category (age category)
                    safe_write(poll_fd[1].fd,(uint8_t *)(cases_array[m].category),cat_len[m]);//write the category
                    safe_write(poll_fd[1].fd,(uint8_t *)(&cases_array[m].counter),sizeof(int));//write the counter
                    destroy_topk(&cases_array[m]);
                  }
                  destroy_topk(&cases_array[4]);//the all info
                  free(cases_array);
                }

              }
              if(disease_size!=0){
                for(int l=0;l<disease_size;l++)
                  free(diseases_found[l]);
                free(diseases_found);
              }
              shutdown(poll_fd[1].fd,SHUT_WR);
              close(poll_fd[1].fd);
            }
            dir_files[i]+=new_in_dir;
            do{
              dates_str[i]=realloc(dates_str[i],dir_files[i]*sizeof(char **));
            }while(dates_str[i]==NULL);
            modification_time[i]=current_mod_time;
            for(int j=0;j<new_in_dir;j++){
              do{
                dates_str[i][dir_files[i]-new_in_dir+j]=malloc(strlen(new_date[j])+1);
              }while(dates_str[i][dir_files[i]-new_in_dir+j]==NULL);
              strcpy(dates_str[i][dir_files[i]-new_in_dir+j],new_date[j]);//append the new filenames in the old array
              free(new_date[j]);
            }
            free(new_date);
          }
        }
        SUCCESS++;
      }
  }
  if(listen(poll_fd[0].fd,1000)){//service one request per time (not multihreaded)
    perror("listen error for worker!");
    exit(1);
  }
  int accept_fd;//accept fd i used to communicate with server thread (server demands-> worker tells)
  while(1){
    retval=poll(poll_fd,(unsigned long)1,-1);//block forever until something is available
    if(retval<0){//signal interrupt
      if(SIGINT_PREV_VAL<SIGINT_COUNTER){
        //if got SIGINT or SIGQUIT
        strcpy(file_path,"../logfiles/log_file.");
        sprintf(file_path+strlen(file_path),"%ld",(long int)getpid());

        int log_fd=open(file_path,O_CREAT|O_WRONLY,0777);

        if(log_fd<0){
          printf("[%ld]\n",(long int)getpid());
          perror("Child log file");
        }else{
          for(int i=0;i<countries;i++)
            dprintf(log_fd,"%s\n",country_name[i]);
          dprintf(log_fd,"TOTAL %d\n",SUCCESS+FAIL);
          dprintf(log_fd,"SUCCESS %d\n",SUCCESS);
          dprintf(log_fd,"FAIL %d\n",FAIL);

          close(log_fd);
        }
        SIGINT_PREV_VAL=SIGINT_COUNTER;
      }else if(SIGUSR1_PREV_VAL<SIGUSR1_COUNTER){//got a SIGUSR1 and got to check the dir for new files
        SIGUSR1_PREV_VAL=SIGUSR1_COUNTER;

        struct tm current_mod_time;
        time_t t1,t2;
        struct stat file_info;

        int new_in_dir;//new in dir count new files
        char **new_date;//dates_str hold the name of new files
                        //because we need to sort them and open them in increasing order
        int found;
        for(int i=0;i<countries;i++){
          new_in_dir=0;
          // printf("%s\n",country_path[i]);
          stat(country_path[i],&dir_info);
          current_mod_time=*(gmtime(&dir_info.st_mtime));
          t1=mktime(&modification_time[i]);//contains last mod time
          t2=mktime(&current_mod_time);//contains current mod time
          if(difftime(t1,t2)<0){//means that dir has new files or user modified an existing file
            do{
              dir=opendir(country_path[i]);//open the dir
            }while(dir==NULL);
            strcpy(file_path,country_path[i]);
            mes_size=strlen(country_path[i]);
            while((entry=readdir(dir))!=NULL){
              found=0;
              if(!strcmp(entry->d_name,"..") || !strcmp(entry->d_name,"."))
                continue;

              for(int l=0;l<dir_files[i];l++)
                if(!strcmp(entry->d_name,dates_str[i][l])){
                  found=1;
                  break;
                }
              if(!found){
                new_in_dir++;//files in dir indicates new files
                if(new_in_dir==1){//malloc()
                  do{
                    new_date=malloc(sizeof(char *));
                  }while(new_date==NULL);
                  do{
                    new_date[0]=malloc(strlen(entry->d_name)+1);
                  }while(new_date[0]==NULL);
                  strcpy(new_date[0],entry->d_name);
                }else{//realloc()
                  do{
                    new_date=realloc(new_date,new_in_dir*sizeof(char*));
                  }while(new_date==NULL);
                  do{
                    new_date[new_in_dir-1]=malloc(strlen(entry->d_name)+1);
                  }while(new_date[new_in_dir-1]==NULL);
                  strcpy(new_date[new_in_dir-1],entry->d_name);
                }
              }
            }
            date_sort(new_date,new_in_dir);
            char ** diseases_found;
            int disease_size=0;
            Topk_ages_rec * cases_array;

            strcat(file_path,"/");
            enum worker_operations w_op=SUMMARY_STATS;
            for(int j=0;j<new_in_dir;j++){
              sprintf(file_path+mes_size+1,"%s",new_date[j]);

              input_from_file(&s,file_path,country_name[i],new_date[j],&diseases_found,&disease_size);//input record from file to system
              do{
                poll_fd[1].fd=socket(server_sock.sin_family,SOCK_STREAM,0);
              }while(poll_fd[1].fd==-1);
              while(connect(poll_fd[1].fd,(sockaddr *)&server_sock,sizeof(server_sock))<0){
                perror("\033[1m\033[31m\t-Handshake failed-\033[0m");
                sleep(1);
              }
              safe_write(poll_fd[1].fd,(uint8_t *)&disease_size,sizeof(int));//at first how many diseases
              safe_write(poll_fd[1].fd,(uint8_t *)&w_op,sizeof(enum worker_operations));//which operation
              int date_len=strlen(new_date[j])+1;
              safe_write(poll_fd[1].fd,(uint8_t *)&date_len,sizeof(int));//how big is the date
              safe_write(poll_fd[1].fd,(uint8_t *)new_date[j],date_len);//the date
              date_len=strlen(country_name[i])+1;
              safe_write(poll_fd[1].fd,(uint8_t *)&date_len,sizeof(int));//how big is the country
              safe_write(poll_fd[1].fd,(uint8_t *)country_name[i],date_len);//the country

              for(int l=0;l<disease_size;l++){
                int d_len=strlen(diseases_found[l])+1;

                cases_array=topk_AgeRanges(&s,4,country_name[i],diseases_found[l],new_date[j],new_date[j],SUMMARY_STATS);
                if(cases_array==NULL){
                  printf("fuuuck\n");
                }else{
                  safe_write(poll_fd[1].fd,(uint8_t *)&d_len,sizeof(int));//how big is the disease
                  safe_write(poll_fd[1].fd,(uint8_t *)diseases_found[l],d_len);//the disease
                  // printf("Ok wrote %d %s\n",*(&d_len),diseases_found[l]);
                  int whole_message=8*sizeof(int);
                  int cat_len[4];
                  for(int m=0;m<4;m++){
                    cat_len[m]=strlen(cases_array[m].category)+1;
                    whole_message+=cat_len[m];
                  }
                  safe_write(poll_fd[1].fd,(uint8_t *)&whole_message,sizeof(int));
                  for(int m=0;m<4;m++){
                    safe_write(poll_fd[1].fd,(uint8_t *)(&cat_len[m]),sizeof(int));//write len of category (age category)
                    safe_write(poll_fd[1].fd,(uint8_t *)(cases_array[m].category),cat_len[m]);//write the category
                    safe_write(poll_fd[1].fd,(uint8_t *)(&cases_array[m].counter),sizeof(int));//write the counter
                    destroy_topk(&cases_array[m]);
                  }
                  destroy_topk(&cases_array[4]);//the all info
                  free(cases_array);
                }

              }
              if(disease_size!=0){
                for(int l=0;l<disease_size;l++)
                  free(diseases_found[l]);
                free(diseases_found);
              }
              shutdown(poll_fd[1].fd,SHUT_WR);
              close(poll_fd[1].fd);
            }
            dir_files[i]+=new_in_dir;
            do{
              dates_str[i]=realloc(dates_str[i],dir_files[i]*sizeof(char **));
            }while(dates_str[i]==NULL);
            modification_time[i]=current_mod_time;
            for(int j=0;j<new_in_dir;j++){
              do{
                dates_str[i][dir_files[i]-new_in_dir+j]=malloc(strlen(new_date[j])+1);
              }while(dates_str[i][dir_files[i]-new_in_dir+j]==NULL);
              strcpy(dates_str[i][dir_files[i]-new_in_dir+j],new_date[j]);//append the new filenames in the old array
              free(new_date[j]);
            }
            free(new_date);
          }
        }
        SUCCESS++;
      }
      continue;
    }
    if((poll_fd[0].revents&POLLIN) == POLLIN){//if data appears on read_pipe then a server thread is trying to connect
      accept_fd=accept(poll_fd[0].fd,NULL,NULL);//dont care who is
      setsockopt(accept_fd,SOL_SOCKET,SO_LINGER,&so_linger,sizeof(so_linger));
      msg_size=(int *)pipe_read(accept_fd,(uint8_t *)read_buffer,buffersize,sizeof(int));
    // printf("---Msg-size %d\n",*msg_size);
      op=(enum worker_operations *)pipe_read(accept_fd,read_buffer,buffersize,sizeof(enum worker_operations));
 // printf("-------------READ %d\n",*op);
      switch(*op){
        case DISEASE_FREQUENCY:
              free(op);
              data=(uint8_t *)pipe_read(accept_fd,(uint8_t *)read_buffer,buffersize,*msg_size);
              free(msg_size);
              count=word_count((char *)data);
              enum worker_operations f_op=DISEASE_FREQUENCY;
              if(count==3){
                sscanf(data,"%s %s %s",virus,date1,date2);
                count=diseaseFrequency(&s,virus,date1,date2,NULL);
                mes_size=sizeof(int);
                safe_write(accept_fd,(uint8_t *)&mes_size,sizeof(int));//write sizeof(int)
                safe_write(accept_fd,(uint8_t *)&f_op,sizeof(enum worker_operations));//write which operation
                safe_write(accept_fd,(uint8_t *)&count,sizeof(int));//write count
              }else{
                sscanf(data,"%s %s %s %s",virus,date1,date2,country);
                count=diseaseFrequency(&s,virus,date1,date2,country);
                mes_size=sizeof(int)+strlen(country)+1;
                safe_write(accept_fd,(uint8_t *)&mes_size,sizeof(int));//write sizeof(int)
                safe_write(accept_fd,(uint8_t *)&f_op,sizeof(enum worker_operations));//write which operation
                safe_write(accept_fd,(uint8_t *)&count,sizeof(int));//write count
                safe_write(accept_fd,(uint8_t *)&country,strlen(country)+1);//write country

              }
              free(data);
              SUCCESS++;
              break;
        case TOPK_AGERANGES:
              free(op);
              data=(uint8_t *)pipe_read(accept_fd,(uint8_t *)read_buffer,buffersize,*msg_size);
              free(msg_size);
              f_op=TOPK_AGERANGES;
              int topk=0;
              sscanf(data,"%d %s %s %s %s",&topk,country,virus,date1,date2);

              Topk_ages_rec * cases_array;

              if(topk>4)
                topk=4;
              else if(topk<1)
                topk=1;

              cases_array=topk_AgeRanges(&s,topk,country,virus,date1,date2,TOPK_AGE);
              if(cases_array==NULL){
                FAIL++;
              }else{
                SUCCESS++;
                int whole_message=((topk+1)*2)*sizeof(int);//check
                int *cat_len;
                do{
                  cat_len=malloc((topk+1)*sizeof(int));
                }while(cat_len==NULL);
                for(int m=0;m<topk;m++){
                  cat_len[m]=strlen(cases_array[m].category)+1;
                  whole_message+=cat_len[m];
                }

                cat_len[topk]=strlen(cases_array[4].category)+1;//contains counter of all counters
                whole_message+=cat_len[topk];//the caegory is "ALL"
                safe_write(accept_fd,(uint8_t *)&whole_message,sizeof(int));//whole message size
                safe_write(accept_fd,(uint8_t *)&f_op,sizeof(enum worker_operations));//which op
                topk++;
                safe_write(accept_fd,(uint8_t *)&topk,sizeof(int));//how many categories


                for(int m=0;m<topk-1;m++){
                  safe_write(accept_fd,(uint8_t *)(&cat_len[m]),sizeof(int));//write len of category (age category)
                  safe_write(accept_fd,(uint8_t *)(cases_array[m].category),cat_len[m]);//write the category
                  safe_write(accept_fd,(uint8_t *)(&cases_array[m].counter),sizeof(int));//write the counter
                }
                safe_write(accept_fd,(uint8_t *)(&cat_len[topk-1]),sizeof(int));//write len of "ALL"
                safe_write(accept_fd,(uint8_t *)(cases_array[4].category),cat_len[topk-1]);//write the category "ALL"
                safe_write(accept_fd,(uint8_t *)(&cases_array[4].counter),sizeof(int));//write the counter sum
                for(int m=0;m<5;m++)
                  destroy_topk(&cases_array[m]);
                free(cases_array);
                free(cat_len);
              }
              break;
        case SEARCH_PATIENT:
              free(op);
              data=(uint8_t *)pipe_read(accept_fd,(uint8_t *)read_buffer,buffersize,*msg_size);
              free(msg_size);
              Patient * pptr;
              pptr=searchPatientRecord(&s,(char *)data);
              int exist;
              f_op=SEARCH_PATIENT;
              if(pptr==NULL){//if doesnt exist
                exist=0;
                safe_write(accept_fd,(uint8_t *)(&exist),sizeof(int));//write 1 to indicate existance
                safe_write(accept_fd,(uint8_t *)&f_op,sizeof(enum worker_operations));//which op
              }else{
                exist=1;//exists
                safe_write(accept_fd,(uint8_t *)(&exist),sizeof(int));//write 1 to indicate existance
                safe_write(accept_fd,(uint8_t *)&f_op,sizeof(enum worker_operations));//which op
                exist=strlen(pptr->id)+1;
                safe_write(accept_fd,(uint8_t *)(&exist),sizeof(int));//write strlen of id
                safe_write(accept_fd,(uint8_t *)pptr->id,exist);//write the id
                exist=strlen(pptr->name)+1;
                safe_write(accept_fd,(uint8_t *)(&exist),sizeof(int));//write strlen of name
                safe_write(accept_fd,(uint8_t *)pptr->name,exist);//write the name
                exist=strlen(pptr->surname)+1;
                safe_write(accept_fd,(uint8_t *)(&exist),sizeof(int));//write strlen of surname
                safe_write(accept_fd,(uint8_t *)pptr->surname,exist);//write the surname
                exist=strlen(pptr->disease)+1;
                safe_write(accept_fd,(uint8_t *)(&exist),sizeof(int));//write strlen of disease
                safe_write(accept_fd,(uint8_t *)pptr->disease,exist);//write the disease
                exist=pptr->age;
                safe_write(accept_fd,(uint8_t *)(&exist),sizeof(int));//write the age
                exist=date_to_str(date1,pptr->entry);
                exist++;//to have the /0
                safe_write(accept_fd,(uint8_t *)(&exist),sizeof(int));//write strlen of entry date
                safe_write(accept_fd,(uint8_t *)date1,exist);//write the entry date
                exist=date_to_str(date2,pptr->exit);
                exist++;//to have the /0

                safe_write(accept_fd,(uint8_t *)(&exist),sizeof(int));//write strlen of exit date
                safe_write(accept_fd,(uint8_t *)date2,exist);//write the exit date
              }
              free(data);
              SUCCESS++;
              break;
        case NUMPADMISSIONS:
        case NUMPDISCHARGES:
              data=(uint8_t *)pipe_read(accept_fd,(uint8_t *)read_buffer,buffersize,*msg_size);
              free(msg_size);
              count=word_count((char *)data);
              f_op=*op;
              free(op);
              int (*funct_to_call)(System *,char *,char *,char *,char *);//either numPatientAdmissions or numPatientDischarges
              if(f_op==NUMPDISCHARGES)
                funct_to_call=&numPatientDischarges;
              else
                funct_to_call=&numPatientAdmissions;

              if(count==3){//if no country is given check al the countries
                sscanf(data,"%s %s %s",virus,date1,date2);
                for(int m=0;m<countries;m++){
                  count=(*funct_to_call)(&s,virus,date1,date2,country_name[m]);
                  mes_size=sizeof(int)+strlen(country_name[m])+1;
                  safe_write(accept_fd,(uint8_t *)&mes_size,sizeof(int));//write len of msg
                  safe_write(accept_fd,(uint8_t *)&f_op,sizeof(enum worker_operations));//write which operation

                  safe_write(accept_fd,(uint8_t *)country_name[m],strlen(country_name[m])+1);//write country
                  safe_write(accept_fd,(uint8_t *)&count,sizeof(int));//write counter
                  // printf("Wrote for %s country\n",country_name[m]);
                }
              }else{
                sscanf(data,"%s %s %s %s",virus,date1,date2,country);
                count=(*funct_to_call)(&s,virus,date1,date2,country);
                mes_size=sizeof(int)+strlen(country)+1;

                safe_write(accept_fd,(uint8_t *)&mes_size,sizeof(int));//write sizeof(int)
                safe_write(accept_fd,(uint8_t *)&f_op,sizeof(enum worker_operations));//write which operation
                safe_write(accept_fd,(uint8_t *)country,strlen(country)+1);//write count
                safe_write(accept_fd,(uint8_t *)&count,sizeof(int));//write count

              }
              free(data);
              SUCCESS++;
              break;

      }
      //terminate the connection
      if(prev_con_fd!=-1)
        close(prev_con_fd);
      prev_con_fd=accept_fd;//ill close the connection in the next connection(to make sure data are read)
      //SAME CODE AS THE CODE WHEN THE POLL IS INTERRUPTED BY A SIGNAL-->A SIGNAL CAN ALSO OCCUR WHEN PROCESSING A REQUEST
      if(SIGINT_PREV_VAL<SIGINT_COUNTER){
        //if got SIGINT or SIGQUIT
        strcpy(file_path,"../logfiles/log_file.");
        sprintf(file_path+strlen(file_path),"%ld",(long int)getpid());

        int log_fd=open(file_path,O_CREAT|O_WRONLY,0777);

        if(log_fd<0){
          printf("[%ld]\n",(long int)getpid());
          perror("Child log file");
        }else{
          for(int i=0;i<countries;i++)
            dprintf(log_fd,"%s\n",country_name[i]);
          dprintf(log_fd,"TOTAL %d\n",SUCCESS+FAIL);
          dprintf(log_fd,"SUCCESS %d\n",SUCCESS);
          dprintf(log_fd,"FAIL %d\n",FAIL);

          close(log_fd);
        }
        SIGINT_PREV_VAL=SIGINT_COUNTER;
      }else if(SIGUSR1_PREV_VAL<SIGUSR1_COUNTER){//got a SIGUSR1 and got to check the dir for new files
        SIGUSR1_PREV_VAL=SIGUSR1_COUNTER;
        struct tm current_mod_time;
        time_t t1,t2;
        struct stat file_info;

        int new_in_dir;//new in dir count new files
        char **new_date;//dates_str hold the name of new files
                        //because we need to sort them and open them in increasing order
        int found;
        for(int i=0;i<countries;i++){
          new_in_dir=0;
          // printf("%s\n",country_path[i]);
          stat(country_path[i],&dir_info);
          current_mod_time=*(gmtime(&dir_info.st_mtime));
          t1=mktime(&modification_time[i]);//contains last mod time
          t2=mktime(&current_mod_time);//contains current mod time
          if(difftime(t1,t2)<0){//means that dir has new files or user modified an existing file
            do{
              dir=opendir(country_path[i]);//open the dir
            }while(dir==NULL);
            strcpy(file_path,country_path[i]);
            mes_size=strlen(country_path[i]);
            while((entry=readdir(dir))!=NULL){
              found=0;
              if(!strcmp(entry->d_name,"..") || !strcmp(entry->d_name,"."))
                continue;

              for(int l=0;l<dir_files[i];l++)
                if(!strcmp(entry->d_name,dates_str[i][l])){
                  found=1;
                  break;
                }
              if(!found){
                new_in_dir++;//files in dir indicates new files
                if(new_in_dir==1){//malloc()
                  do{
                    new_date=malloc(sizeof(char *));
                  }while(new_date==NULL);
                  do{
                    new_date[0]=malloc(strlen(entry->d_name)+1);
                  }while(new_date[0]==NULL);
                  strcpy(new_date[0],entry->d_name);
                }else{//realloc()
                  do{
                    new_date=realloc(new_date,new_in_dir*sizeof(char*));
                  }while(new_date==NULL);
                  do{
                    new_date[new_in_dir-1]=malloc(strlen(entry->d_name)+1);
                  }while(new_date[new_in_dir-1]==NULL);
                  strcpy(new_date[new_in_dir-1],entry->d_name);
                }
              }
            }
            date_sort(new_date,new_in_dir);
            char ** diseases_found;
            int disease_size=0;
            Topk_ages_rec * cases_array;

            strcat(file_path,"/");
            enum worker_operations w_op=SUMMARY_STATS;
            for(int j=0;j<new_in_dir;j++){
              sprintf(file_path+mes_size+1,"%s",new_date[j]);

              input_from_file(&s,file_path,country_name[i],new_date[j],&diseases_found,&disease_size);//input record from file to system
              do{
                poll_fd[1].fd=socket(server_sock.sin_family,SOCK_STREAM,0);
              }while(poll_fd[1].fd==-1);
              while(connect(poll_fd[1].fd,(sockaddr *)&server_sock,sizeof(server_sock))<0){
                perror("\033[1m\033[31m\t-Handshake failed-\033[0m");
                sleep(1);
              }
              safe_write(poll_fd[1].fd,(uint8_t *)&disease_size,sizeof(int));//at first how many diseases
              safe_write(poll_fd[1].fd,(uint8_t *)&w_op,sizeof(enum worker_operations));//which operation
              int date_len=strlen(new_date[j])+1;
              safe_write(poll_fd[1].fd,(uint8_t *)&date_len,sizeof(int));//how big is the date
              safe_write(poll_fd[1].fd,(uint8_t *)new_date[j],date_len);//the date
              date_len=strlen(country_name[i])+1;
              safe_write(poll_fd[1].fd,(uint8_t *)&date_len,sizeof(int));//how big is the country
              safe_write(poll_fd[1].fd,(uint8_t *)country_name[i],date_len);//the country

              for(int l=0;l<disease_size;l++){
                int d_len=strlen(diseases_found[l])+1;

                cases_array=topk_AgeRanges(&s,4,country_name[i],diseases_found[l],new_date[j],new_date[j],SUMMARY_STATS);
                if(cases_array==NULL){
                  printf("fuuuck\n");
                }else{
                  safe_write(poll_fd[1].fd,(uint8_t *)&d_len,sizeof(int));//how big is the disease
                  safe_write(poll_fd[1].fd,(uint8_t *)diseases_found[l],d_len);//the disease
                  // printf("Ok wrote %d %s\n",*(&d_len),diseases_found[l]);
                  int whole_message=8*sizeof(int);
                  int cat_len[4];
                  for(int m=0;m<4;m++){
                    cat_len[m]=strlen(cases_array[m].category)+1;
                    whole_message+=cat_len[m];
                  }
                  safe_write(poll_fd[1].fd,(uint8_t *)&whole_message,sizeof(int));
                  for(int m=0;m<4;m++){
                    safe_write(poll_fd[1].fd,(uint8_t *)(&cat_len[m]),sizeof(int));//write len of category (age category)
                    safe_write(poll_fd[1].fd,(uint8_t *)(cases_array[m].category),cat_len[m]);//write the category
                    safe_write(poll_fd[1].fd,(uint8_t *)(&cases_array[m].counter),sizeof(int));//write the counter
                    destroy_topk(&cases_array[m]);
                  }
                  destroy_topk(&cases_array[4]);//the all info
                  free(cases_array);
                }

              }
              if(disease_size!=0){
                for(int l=0;l<disease_size;l++)
                  free(diseases_found[l]);
                free(diseases_found);
              }
              shutdown(poll_fd[1].fd,SHUT_WR);
              close(poll_fd[1].fd);
            }
            dir_files[i]+=new_in_dir;
            do{
              dates_str[i]=realloc(dates_str[i],dir_files[i]*sizeof(char **));
            }while(dates_str[i]==NULL);
            modification_time[i]=current_mod_time;
            for(int j=0;j<new_in_dir;j++){
              do{
                dates_str[i][dir_files[i]-new_in_dir+j]=malloc(strlen(new_date[j])+1);
              }while(dates_str[i][dir_files[i]-new_in_dir+j]==NULL);
              strcpy(dates_str[i][dir_files[i]-new_in_dir+j],new_date[j]);//append the new filenames in the old array
              free(new_date[j]);
            }
            free(new_date);
          }
        }
        SUCCESS++;
      }
      ans_count++;
      if(ans_count%50==0)//printf every 50 answered request
        printf("\033[1m\033[32m\tSuccessfully answered %d client requests [Worker %d]\033[0m\n",ans_count,worker_id);
    }
  }
  close(prev_con_fd);
  sem_close(mutex_sem);
  sem_close(workers_sync);
  sem_close(worker_notif);
  pause();
  return 0;
}
