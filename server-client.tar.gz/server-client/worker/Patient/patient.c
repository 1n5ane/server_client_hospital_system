#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "patient.h"
#include "../Date/date.h"


Patient * allocPatient(void){
  return malloc(sizeof(Patient));
}

int setPatient(Patient * pptr,char *i,char *n,char *s,char *d,char *c,int a,char *en,char *ex){
  if(setDate(&pptr->entry,en) || setDate(&pptr->exit,ex))
    return 1;//indicate wrong date format


  pptr->id=malloc(strlen(i)+1);
  if(pptr->id==NULL){
    printf("Malloc failed!\n");
    return -1;//indicates system error
  }
  strcpy(pptr->id,i);

  pptr->name=malloc(strlen(n)+1);
  if(pptr->name==NULL){
    printf("Malloc failed!\n");
    return -1;//indicates system error
  }
  strcpy(pptr->name,n);

  pptr->surname=malloc(strlen(s)+1);
  if(pptr->surname==NULL){
    printf("Malloc failed!\n");
    return -1;//indicates system error
  }
  strcpy(pptr->surname,s);

  pptr->disease=malloc(strlen(d)+1);
  if(pptr->disease==NULL){
    printf("Malloc failed!\n");
    return -1;//indicates system error
  }
  strcpy(pptr->disease,d);

  pptr->country=malloc(strlen(c)+1);
  if(pptr->country==NULL){
    printf("Malloc failed!\n");
    return -1;//indicates system error
  }
  strcpy(pptr->country,c);
  pptr->age=a;
  return 0;
}

void printPatient(Patient * pptr){//i use pointer because i dont want the whole struct to be copied
  printf("%s %s %s %s %s %d ",pptr->id,pptr->name,pptr->surname,pptr->disease,pptr->country,pptr->age);
  printf("%d-%d-%d ",pptr->entry.day,pptr->entry.month,pptr->entry.year);
  printDate(pptr->exit);
  return ;
}

void freePatient(Patient * pptr){
  free(pptr->id);
  free(pptr->name);
  free(pptr->surname);
  free(pptr->disease);
  free(pptr->country);
  free(pptr);
}
