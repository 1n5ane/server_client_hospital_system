#ifndef __PATIENT_H__
#define __PATIENT_H__
#include "../Date/date.h"
typedef struct patient{
  char * id;
  char * name;
  char * surname;
  char * disease;
  char * country;
  int age;
  Date entry;
  Date exit;
}Patient;

Patient * allocPatient(void);
int setPatient(Patient * pptr,char *i,char *n,char *s,char *d,char *c,int a,char *en,char *ex);
void printPatient(Patient * pptr);//i use pointer because i dont want the whole struct to be copied
void freePatient(Patient * pptr);

#endif
