#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <dirent.h>
#include <unistd.h>
#include "../Hash/hashfuncts.h"
#include "../Patient/patient.h"
#include "../Tree/avltree.h"
#include "system.h"

int BUCKET_SIZE=168;//means that each bucket has 10 records(string_ptr,tree_ptr)(10*16) + pointer to next bucket(8bytes) and should be mult of 8
                  //because we dont want fragmentation

void input_from_file(System * sptr,char *file_path,char *country_name,char *date_str,char ***disease,int *disease_size){//input record from file to system
  FILE * fp=fopen(file_path,"r");

  if(fp==NULL)
    return ;


  *disease_size=0;
  Patient * pptr;
  char id[30];
  char name[30];
  char surname[30];
  char d[30];
  char age[5];
  int a;
  char what[6];
  char line[200];
  int found;
  while(!feof(fp)){
    found=0;
    line[0]='\0';
    fgets(line,199,fp);
    if(strlen(line)<3)
      continue;
    line[strlen(line)-1]='\0';
    sscanf(line,"%s %s %s %s %s %s",id,what,name,surname,d,age);
    do{
      pptr=allocPatient();
    }while(pptr==NULL);
    a=atoi(age);
    if((int)strlen(what)==5){//means ENTER
      setPatient(pptr,id,name,surname,d,country_name,a,date_str,"-");
      if(insertPatientRecord(sptr,pptr)){//if patient exists
        fprintf(stderr,"Patient with id %s already exists! [process %ld]\n",id,(long int)getpid());
        freePatient(pptr);
      }else{//---------------------
        if(*disease_size==0){
          do{
            *disease=malloc(sizeof(char *));
          }while(*disease==NULL);
          do{
            **disease=malloc(strlen(pptr->disease)+1);
          }while(**disease==NULL);
          strcpy(**disease,pptr->disease);
          *disease_size=*disease_size+1;
          found=1;
        }else{
          for(int i=0;i<*disease_size;i++){
            if(!strcmp(*((*disease)+i),pptr->disease)){
              found=1;
              break;
            }
          }
        }
        if(!found){
          do{
            *disease=realloc(*disease,(*disease_size+1)*sizeof(char *));
          }while(*disease==NULL);
          *disease_size=*disease_size+1;
          do{
            *((*disease)+*disease_size-1)=malloc(strlen(pptr->disease)+1);
          }while(*((*disease)+*disease_size-1)==NULL);
          strcpy(*((*disease)+*disease_size-1),pptr->disease);
        }
      }
    }else{//means exit
      free(pptr);
      if(recordPatientExit(sptr,id,date_str)==-1)//if EXIT then add exit date to patient with id
        printf("Error! Patient %s in dir %s in file %s has no prior ENTER!\n",id,country_name,date_str);
    }
  }
  fclose(fp);
}

void system_init(System * sptr,int diseaseSize,int countrySize,int bsize){
  int val;

  listInit(&sptr->patient_list);
  do{
    val=createHashtable(&sptr->diseaseHashtable,h1,diseaseSize,bsize);//h1 is the adress of hashfunct 1
  }while(val==-1);//try again if fails;

  do{
    val=createHashtable(&sptr->countryHashtable,h2,countrySize,bsize);//h2 is the adress of hashfunct 2
  }while(val==-1);//try again if fails;
  sptr->maxHeap=NULL;
  return  ;
}

int insertPatientRecord(System * sptr,Patient * pptr){//0 in case of success,1 otherwise
  int val;
  do{
    val=listAppend(&sptr->patient_list,pptr,CHECKFORDUPLICATES);
    if(val==1)
      return 1;//patient already exists in system
  }while(val==-1);//try again if malloc fails

  add_to_hashtable(&sptr->diseaseHashtable,pptr,pptr->disease);
  add_to_hashtable(&sptr->countryHashtable,pptr,pptr->country);
  return 0;
}

int recordPatientExit(System * sptr,char * id,char * date){//1 indicates wrong date (wrong format or smalelr date than entry)
  Date new_date;                                          //,0 all ok,-1 inicates patient doesnt exist
  if(setDate(&new_date,date))
    return 1;

  Patient * pptr;
  pptr=getPatient_by_id(&sptr->patient_list,id);
  if(pptr==NULL)
    return -1;

  pptr->exit=new_date;//default assignement is cool
  return 0;
}

int diseaseFrequency(System * sptr,char * virus,char * date1,char * date2,char * country){//return number of patients,else -1 (wrong date)
  Date d1;
  Date d2;
  if(setDate(&d1,date1) || setDate(&d2,date2))
    return -1;
  if(cmpDate(d1,d2)==1)
    return -1;
  Avltree * tptr;

  tptr=get_Tree_From_Hashtable(&sptr->diseaseHashtable,virus);
  if(tptr==NULL)
    return 0;//0 patients if virus doesn't exist in system
  return recursive_count(tptr->root,d1,d2,country,COUNTRY,FULL_CHECK);
}

int numPatientAdmissions(System * sptr,char * virus,char * date1,char * date2,char * country){
  Date d1;
  Date d2;
  if(setDate(&d1,date1) || setDate(&d2,date2))
    return -1;
  if(cmpDate(d1,d2)==1)
    return -1;
  Avltree * tptr;
  tptr=get_Tree_From_Hashtable(&sptr->diseaseHashtable,virus);
  if(tptr==NULL)
    return 0;//0 patients if virus doesn't exist in system
  return recursive_count(tptr->root,d1,d2,country,COUNTRY,ENTERED);
}
int numPatientDischarges(System * sptr,char * virus,char * date1,char * date2,char * country){
  Date d1;
  Date d2;
  if(setDate(&d1,date1) || setDate(&d2,date2))
    return -1;
  if(cmpDate(d1,d2)==1)
    return -1;
  Avltree * tptr;
  tptr=get_Tree_From_Hashtable(&sptr->diseaseHashtable,virus);
  if(tptr==NULL)
    return 0;//0 patients if virus doesn't exist in system
  return recursive_count(tptr->root,d1,d2,country,COUNTRY,EXITED);
}

//could have used diseaseFrquency inside topk_Diseases but it would be slower...
Topk_ages_rec *topk_AgeRanges(System * sptr,int k,char * country,char * disease,char * date1,char * date2,enum options_t op){
  Date d1;
  Date d2;
  Avltree * tptr;
  const char * age;

  int * age_ranges=NULL;
  sptr->maxHeap=heap_alloc();
  heap_init(sptr->maxHeap);

  if(setDate(&d1,date1) || setDate(&d2,date2))
    return NULL;
  if(cmpDate(d1,d2)==1)
    return NULL;

  tptr=get_Tree_From_Hashtable(&sptr->diseaseHashtable,disease);
  if(tptr==NULL){
    heap_destroy(sptr->maxHeap);
    sptr->maxHeap=NULL;
    return NULL;
  }
  int sum=0;
  Topk_ages_rec * rec_array=NULL;
  do{
    rec_array=malloc(5*sizeof(Topk_ages_rec));//max 4 age ranges-> so max 5 records (last is overall infos)
  }while(rec_array==NULL);
  int ret_val;
  if(op==TOPK_AGE)
    ret_val=count_AgeRanges(tptr->root,d1,d2,country,&age_ranges,1);// is for topk
  else
    ret_val=count_AgeRanges(tptr->root,d1,d2,country,&age_ranges,0);//0 is for summary stats

  if(ret_val==0){//if successfull
    if(op==TOPK_AGE){
      heap_insert(sptr->maxHeap,"0-20",age_ranges[0]);
      heap_insert(sptr->maxHeap,"21-40",age_ranges[1]);
      heap_insert(sptr->maxHeap,"41-60",age_ranges[2]);
      heap_insert(sptr->maxHeap,"61+",age_ranges[3]);
    }
    for(int i=0;i<4;i++)
      sum+=age_ranges[i];

    set_topk(&rec_array[0],"0-20",age_ranges[0]);
    set_topk(&rec_array[1],"21-40",age_ranges[1]);
    set_topk(&rec_array[2],"41-60",age_ranges[2]);
    set_topk(&rec_array[3],"61+",age_ranges[3]);
    set_topk(&rec_array[4],"ALL",sum);

      // printf("TOP-K DISEASES FOR %s BETWEEN THE DATES PROVIDED\n",country);
    if(op==TOPK_AGE){
      Topk_ages_rec tmp;
      int count;
      for(int i=0;i<k;i++){
        if(extract_max(sptr->maxHeap,&age,(long int *)&count)!=1){
          for(int j=i;j<4;j++)
            if(count==rec_array[j].counter){
              tmp=rec_array[i];
              rec_array[i]=rec_array[j];
              rec_array[j]=tmp;
            }
        }else
          break;
      }
    }
    free(age_ranges);
    heap_destroy(sptr->maxHeap);
    sptr->maxHeap=NULL;
    return rec_array;
  }else{
    heap_destroy(sptr->maxHeap);
    sptr->maxHeap=NULL;
    return NULL;//returns the array--> the caller is obliged to free it
  }
}

Patient * searchPatientRecord(System * sptr,char * id){//in case of success patient ptr is returned,else NULL
  return getPatient_by_id(&sptr->patient_list,id);
}
void system_print(System * sptr){
  printf("----------------Printing list!---------------------\n");
  printList(sptr->patient_list);
  printf("----------------Printing Disease hashtable!---------------------\n");
  printHashtable(&sptr->diseaseHashtable);
  printf("----------------Printing Country hashtable!---------------------\n");
  printHashtable(&sptr->countryHashtable);
}

void destroySystem(System * sptr){
  listDestroy(&sptr->patient_list,FREE_DATA_MEMBERS);
  destroyHashtable(&sptr->diseaseHashtable);
  destroyHashtable(&sptr->countryHashtable);
  return ;
}
