#ifndef __SYSTEM_H__
#define __SYSTEM_H__
#include "../Hash/hashtable.h"
#include "../List/plist.h"
#include "../Heap/heap.h"
#include "../../topk_ages_rec.h"

enum options_t{SUM_STATS,TOPK_AGE};

typedef struct system{
  List patient_list;
  Hashtable diseaseHashtable;
  Hashtable countryHashtable;//maybe not needed here
  Heap * maxHeap;
}System ;

void input_from_file(System * sptr,char *file_path,char *country_name,char *date_str,char ***disease,int *disease_size);//input record from file to system
void system_init(System * sptr,int diseaseSize,int countrySize,int bsize);
int insertPatientRecord(System * sptr,Patient * pptr);//0 in case of success,1 otherwise
int recordPatientExit(System * sptr,char * id,char * date);
int diseaseFrequency(System * sptr,char * virus,char * date1,char * date2,char * country);
int numPatientAdmissions(System * sptr,char * virus,char * date1,char * date2,char * country);
int numPatientDischarges(System * sptr,char * virus,char * date1,char * date2,char * country);
Topk_ages_rec *topk_AgeRanges(System * sptr,int k,char * country,char * disease,char * date1,char * date2,enum options_t op);
Patient * searchPatientRecord(System * sptr,char * id);//in case of success patient ptr is returned,else NULL
void destroySystem(System * sptr);
void system_print(System * sptr);
#endif
