#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "date.h"

int setDate(Date * dptr,const char * date){//returns 1 in case of error else 0
  if(!strcmp(date,"-")){
    dptr->day=0;
    dptr->month=0;
    dptr->year=0;
    return 0;
  }else if(strlen(date)<8)
    return 1;//invalid

  char * token;
  char d[11];
  strncpy(d,date,11);
  token=strtok(d,"-");
  dptr->day=atoi(token);
  if(dptr->day==0 ||dptr->day>31)
    return 1;//invalid;
  token=strtok(NULL,"-");
  dptr->month=atoi(token);
  if(dptr->month==0 ||dptr->month>12)
    return 1;
  dptr->year=atoi(token + strlen(token)+1);
  if(dptr->year<=0|| dptr->year>9999)
    return 1;
  return 0;
}
//phgh: https://stackoverflow.com/questions/1442116/how-to-get-the-date-and-time-values-in-a-c-program
int cmpDate(const Date d1,const Date d2){//0 if ==,-1 if d1<d2,1 if d1>d2
  if(d2.day==0){//indicates "-" in date
    time_t t=time(NULL);
    struct tm tm = *localtime(&t);
    Date today;
    today.year=tm.tm_year+1900;
    today.month=tm.tm_mon+1;
    today.day=tm.tm_mday;
    return cmpDate(d1,today);
  }
  if(d1.year==d2.year){
    if(d1.month==d2.month){
      if(d1.day==d2.day){
        return 0;
      }else if(d1.day<d2.day){
        return -1;
      }else{
        return 1;
      }
    }else if(d1.month<d2.month){
      return -1;
    }else{
      return 1;
    }
  }else if(d1.year<d2.year){
    return -1;
  }
  return 1;
}

int dateBetween(const Date this_date,const Date d1,const Date d2){//returns 1 if this_date is in [d1,d2]
  if((cmpDate(d1,this_date)==-1) && (cmpDate(d2,this_date)==1))//d1<this_date<d2
    return 1;
  else if(cmpDate(d1,this_date)==0)
    return 1;
  else if(cmpDate(d2,this_date)==0)
    return 1;
  return 0;
}

//phgh: https://www.geeksforgeeks.org/quick-sort/
void swap(char **date1,char ** date2){
    char * tmp=*date1;
    *date1=*date2;
    *date2=tmp;
    return ;
}

int partition(char **arr,int low,int high){
    // pivot (Element to be placed at right position)
    Date pivot;
    setDate(&pivot,arr[high]);

    int i = (low - 1);  // Index of smaller element

    for (int j = low; j <= high- 1; j++)
    {
        Date cur;
        setDate(&cur,arr[j]);
        // If current element is smaller than the pivot
        if (cmpDate(cur,pivot)==-1)
        {
            i++;    // increment index of smaller element
            swap(&arr[i],&arr[j]);
        }
    }
    swap(&arr[i + 1],&arr[high]);
    return (i + 1);
}

void quick_sort(char ** arr,int low,int high){
  if (low < high)
    {
        /* pi is partitioning index, arr[pi] is now
           at right place */
        int pi = partition(arr, low, high);

        quick_sort(arr, low, pi - 1);  // Before pi
        quick_sort(arr, pi + 1, high); // After pi
    }
}

void date_sort(char ** date_str,int size){
  quick_sort(date_str,0,size-1);
  return ;
}

int date_to_str(char * buff,Date date){//returns len of str
  if(date.day==0){//means -
    char *paules="--";
    strcpy(buff,paules);
    return 2;
  }

  sprintf(buff,"%d",date.day);
  int len=strlen(buff);
  buff[len]='-';
  sprintf(buff+len+1,"%d",date.month);
  len=strlen(buff);
  buff[len]='-';
  sprintf(buff+len+1,"%d",date.year);
  return strlen(buff);
}

void printDate(const Date date){
  if(date.day==0){
    printf("-\n");
    return ;
  }
  printf("%d",date.day);
  printf("-");
  printf("%d",date.month);
  printf("-");
  printf("%d\n",date.year);
  return ;
}
