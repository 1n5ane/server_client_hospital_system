#ifndef __DATE_H__
#define __DATE_H__
#include <stdint.h>
typedef struct date{
  uint8_t day;
  uint8_t month;
  int year;
}Date;

int setDate(Date * dptr,const char * date);//returns 1 in case of error else 0
int cmpDate(const Date d1,const Date d2);//0 if ==,-1 if d1<d2,1 if d1>d2
int dateBetween(const Date this_date,const Date d1,const Date d2);//returns 1 if this_date is in [d1,d2];
void date_sort(char ** date_str,int size);
void printDate(const Date date);
int date_to_str(char * buff,Date date);//returns len of str


#endif
