#ifndef __HASHFUNCTS_H__
#define __HASHFUNCTS_H__
unsigned long h1(const char *);
unsigned long h2(const char *);
#endif
