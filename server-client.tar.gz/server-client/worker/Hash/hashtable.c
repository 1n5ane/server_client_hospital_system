#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hashtable.h"
#include "../Tree/avltree.h"

extern int BUCKET_SIZE;

int createBucket(Bucket * bptr,int size){//-1 indicates system failure,0 for success
  bptr->data=malloc(size);
  memset(bptr->data,'0',size);
  if(bptr->data==NULL){
    printf("Malloc failed!\n");
    return -1;
  }
  bptr->size=size-sizeof(Bucket *);//SIZE OF BUCKETS AT START IS (BUCKET_SIZE-sizeof(Bucket *))
  Bucket * null=NULL;             //so i always have the available space i can use
  memcpy(bptr->data+(BUCKET_SIZE-sizeof(Bucket *)),&null,sizeof(Bucket *));//write null as next bucket to new bucket

  return 0;
}

void freeBucket(Bucket * bptr){//must destroy the bucketlist and all of its contents
  if(bptr==NULL)
    return ;

  int entries;
  int occupied_space;
  char * name;
  Avltree * tptr;
  occupied_space=BUCKET_SIZE-bptr->size-sizeof(Bucket *);
  entries=occupied_space/(sizeof(char *)+sizeof(Avltree *));
  // printf("Entries %d!\n",entries);
  for(int i=0;i<entries;i++){
    memcpy(&name,bptr->data+i*(sizeof(char*)+sizeof(Avltree*)),sizeof(char*));
    memcpy(&tptr,bptr->data+i*(sizeof(char*)+sizeof(Avltree*))+sizeof(char *),sizeof(Avltree *));
    free(name);
    destroyAvltree(tptr);
    free(tptr);//also free the pointer
  }
  freeBucket(get_next_Bucket(bptr));
  free(bptr->data);
  free(bptr);
  return ;
}

void destroyHashtable(Hashtable *hptr){
  for(int i=0;i<hptr->size;i++)
    if(hptr->array[i]!=NULL)
      freeBucket(hptr->array[i]);
  free(hptr->array);
  return ;
}


int createHashtable(Hashtable * hptr,unsigned long (*hashfunct)(const char *),int tablesize,int bucketsize){//-1 indicates system failure,0 for success
  hptr->array=malloc(tablesize*sizeof(Bucket *));
  if(hptr->array==NULL){
    printf("Malloc failed!\n");
    return -1;
  }
  for(int i=0;i<tablesize;i++)
    hptr->array[i]=NULL;//buckets will be created on the fly

  hptr->hashfunct=hashfunct;//assign its hashfunct
  hptr->size=tablesize;
  return 0;
}

Bucket * get_next_Bucket(Bucket * bptr){//returns next bucket from bptr->NULL if no bucket
  Bucket * tmp;
  memcpy(&tmp,(Bucket **)(bptr->data+(BUCKET_SIZE-sizeof(Bucket *))),sizeof(Bucket *));//pointer to next bucket last
  return tmp;
}

int add_to_bucket(Bucket * bptr,Patient *pptr,const char * str){//0 indicates success
  /* this functs makes a new str entry and
  a new tree ptr inserting the patient there (entry date)<-the first time
  ELSE if str already exists in bucket list just the insert in tree  */
  int exist=0;
  int which_entry;//1st entry (1st str ptr and tree ptr),2nd(2nd str ptr and tree ptr)....
  Bucket * next=bptr;;
  int occupied_space;
  int entries;
  char * entry_str;
  Avltree * tptr;
  do{
    bptr=next;
    occupied_space=BUCKET_SIZE-bptr->size-sizeof(Bucket *);
    entries=occupied_space/(sizeof(char *)+sizeof(Avltree *));
    //printf("Entries %d*\n",entries);
    for(int i=1;i<=entries;i++){
      memcpy(&entry_str,bptr->data+(i-1)*(sizeof(char *)+sizeof(Avltree *)),sizeof(char *));
      //printf("-------%s\n",entry_str);
      if(!strcmp(str,entry_str)){
        exist=1;
        which_entry=i;
        memcpy(&tptr,bptr->data+(i-1)*(sizeof(char *)+sizeof(Avltree *))+sizeof(char *),sizeof(Avltree *));
        break;
      }
    }
    if(exist)
      break;
    next=get_next_Bucket(bptr);
  }while(next!=NULL);

  if(!exist){//if doesnt exist
    if(bptr->size<(sizeof(char *)+sizeof(Avltree *))){//if there is NO space in current bucket
      Bucket * tmp_bucket;
      do{
        tmp_bucket=malloc(sizeof(Bucket));
      }while(tmp_bucket==NULL);
      int val;
      do{
        val=createBucket(tmp_bucket,BUCKET_SIZE);
      }while(val==-1);
      memcpy(bptr->data+(BUCKET_SIZE-sizeof(Bucket *)),&tmp_bucket,sizeof(Bucket *));
      bptr=tmp_bucket;
      entries=0;
    }

    char * tmp=malloc(strlen(str)+1);
    strcpy(tmp,str);
    tptr=newAvltree();
    memcpy(bptr->data+entries*(sizeof(char *)+sizeof(Avltree *)),&tmp,sizeof(char*));//write string pointer
    memcpy(bptr->data+entries*(sizeof(char *)+sizeof(Avltree *))+sizeof(char *),&tptr,sizeof(Avltree*));//write avlpointer
    bptr->size=bptr->size-(sizeof(char*)+sizeof(Avltree *));
  }
  int val;
  do{
    val=insertAvl(tptr,pptr);
  }while(val==-1);//try again if malloc fails
  return 0;
}

void printBucket(Bucket * bptr){
  int entries;
  int occupied_space;
  occupied_space=BUCKET_SIZE-bptr->size-sizeof(Bucket *);
  entries=occupied_space/(sizeof(char *)+sizeof(Avltree *));
  printf("%d entries in bucket\n",entries);
  char * str;
  Avltree * tptr;
  for(int i=0;i<entries;i++){
    memcpy(&str,bptr->data+i*(sizeof(char *)+sizeof(Avltree *)),sizeof(char *));
    memcpy(&tptr,bptr->data+i*(sizeof(char *)+sizeof(Avltree *)) + sizeof(char *),sizeof(Avltree *));
    printf("--Virus: %s\n",str);
    printInorder(tptr);
  }
  return ;
}

void printHashtable(Hashtable * hptr){
  Bucket * cur;
  printf("SIZE OF TABLE: %d\n",hptr->size);
  printf("SIZE OF BUCKET: %d\n",BUCKET_SIZE);
  for(int i=0;i<hptr->size;i++){
    cur=hptr->array[i];
    printf("== index %d ==\n",i);
    while(cur!=NULL){
      printBucket(cur);
      cur=get_next_Bucket(cur);
    }
  }
  return ;
}

int add_to_hashtable(Hashtable * hptr,Patient * pptr,const char * str_to_be_hashed){//0 indicates success,-1 error
  if(hptr==NULL)
    return -1;
  unsigned long hash;
  hash=hptr->hashfunct(str_to_be_hashed);
  int index=hash%hptr->size;
  //printf("Index for %s with hash %ld: %d\n",str_to_be_hashed,hash,index);
  if(hptr->array[index]==NULL){
    do{
      hptr->array[index]=malloc(sizeof(Bucket));
    }while(hptr->array[index]==NULL);

    createBucket(hptr->array[index],BUCKET_SIZE);
  }
  add_to_bucket(hptr->array[index],pptr,str_to_be_hashed);
  return 0;
}

Avltree * get_Tree_From_Hashtable(Hashtable * hptr,char * key){
  int index;
  long int hash;
  Avltree * tptr=NULL;
  hash=hptr->hashfunct(key);
  index=hash%hptr->size;
  Bucket * cur=hptr->array[index];

  if(cur==NULL)
    return NULL;

  int entries;
  int occupied_space;
  char * curr_key;

  do{
    occupied_space=BUCKET_SIZE-cur->size-sizeof(Bucket *);
    entries=occupied_space/(sizeof(char *)+sizeof(Avltree *));
    for(int i=0;i<entries;i++){
      memcpy(&curr_key,cur->data+i*(sizeof(char *)+sizeof(Avltree *)),sizeof(char *));
      if(!strcmp(curr_key,key)){//found
        memcpy(&tptr,cur->data+i*(sizeof(char *)+sizeof(Avltree *)) + sizeof(char *),sizeof(Avltree *));
        return tptr;
      }
    }
    cur=get_next_Bucket(cur);
  }while(cur!=NULL);
  return tptr;
}
