#ifndef __HASHTABLE_H__
#define __HASHTABLE_H__
#include <stdint.h>
#include "../Patient/patient.h"

typedef struct avltree Avltree;
typedef struct bucket{
  int size;//AVAILABLE size of bucket in bytes
  uint8_t * data;//raw data
}Bucket;

typedef struct hashtable{
  int size;//size of hashtable
  unsigned long (*hashfunct)(const char *);
  Bucket ** array;//array of pointers to buckets
}Hashtable;

int createBucket(Bucket * bptr,int size);
Bucket * get_next_Bucket(Bucket * bptr);//returns next bucket from bptr.NULL if no bucket
void freeBucket(Bucket * bptr);
void printBucket(Bucket * bptr);
void printHashtable(Hashtable * hptr);
int createHashtable(Hashtable * hptr,unsigned long (*hashfunct)(const char *),int tablesize,int bucketsize);
int add_to_hashtable(Hashtable * hptr,Patient * pptr,const char * str_to_be_hashed);
Avltree * get_Tree_From_Hashtable(Hashtable * hptr,char * key);
void destroyHashtable(Hashtable *hptr);

#endif
