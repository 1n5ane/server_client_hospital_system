#include <stdio.h>
#include <string.h>

unsigned long h1(const char *x){//djb2hash //http://www.cse.yorku.ca/~oz/hash.html
  unsigned long hash=5381;
  int g=33;
  for(int i=0;i<strlen(x);i++){
    hash=hash*g+x[i];
  }
  return hash;
}

unsigned long h2(const char *x){//sdbm hash //http://www.cse.yorku.ca/~oz/hash.html
  unsigned long hash=0;
  for(int i=0;i<strlen(x);i++){
    hash=x[i] + (hash<<6) + (hash<<16) -hash;
  }
  return hash;
}

