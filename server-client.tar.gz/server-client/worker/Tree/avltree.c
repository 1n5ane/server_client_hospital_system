#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "avltree.h"
#include "../List/plist.h"//following headers are included in avltree.h
#include "../Patient/patient.h"//i include them again
#include "../Date/date.h"//->reminder to add them as constraint in makefile



Tnode * newNode(Date date){
  Tnode * tmp=malloc(sizeof(Tnode));
  if(tmp==NULL)
    return NULL;
  tmp->height=1;
  tmp->left=NULL;
  tmp->right=NULL;
  tmp->date=date;//default assign is cool
  listInit(&tmp->plist);//initialize list
  return tmp;
}

void addPatient(Tnode * n,Patient * p){
  //printList(n->plist);
  while(listAppend(&n->plist,p,JUSTAPPEND)==-1);//while malloc fails try again
  return ;
}

int Patients_in_node(Tnode * n){
  return n->plist.size;
}

void freeTnode(Tnode * n){//recursively destroys all inodes and frees the lists
  if(n==NULL)
    return ;
  freeTnode(n->left); //Postorder
  freeTnode(n->right);//        Traversal
  listDestroy(&n->plist,KEEP_DATA_MEMBERS);//patients will be destroyed once in the original list
  free(n);
  return ;
}

int height(Tnode * n){
  if(n==NULL)
    return 0;
  return n->height;
}
int max(int a, int b) {
    return (a > b)? a : b;
}

Avltree * newAvltree(void){
  Avltree * tmp;
  do{
    tmp=malloc(sizeof(Avltree));
  }while(tmp==NULL);
  tmp->root=NULL;//init
  return tmp;
}

int getBalance(Tnode *n){
    if (n == NULL)
        return 0;
    return height(n->left) - height(n->right);
}

Tnode * rightRotate(Tnode * x){
  Tnode * y=x->left;
  Tnode * rchild=y->right;
  //right
  y->right=x;
  x->left=rchild;
  //update heights
  x->height = max(height(x->left), height(x->right))+1;
  y->height = max(height(y->left), height(y->right))+1;
  return y;//return new root
}

Tnode * leftRotate(Tnode * x){
  Tnode * y=x->right;
  Tnode * lchild=y->left;
  //right rotate
  y->left=x;
  x->right=lchild;
  //update heights
  x->height = max(height(x->left), height(x->right))+1;
  y->height = max(height(y->left), height(y->right))+1;

  return y;
}

int insertNode(Tnode ** n,Patient * p){//-1 indicates system error (malloc fail),0==cool,1 indicates no node insertes just added
                                      //in list
  int val;
  if(*n==NULL){
    *n=newNode(p->entry);
    if(*n==NULL){
      val=-1;
    }else{
      val=0;
      addPatient(*n,p);
    }
    return val;
  }

  if(cmpDate(p->entry,(*n)->date)==-1)//if key<root
    val=insertNode(&((*n)->left),p);
  else if(cmpDate(p->entry,(*n)->date)==1)//if key>root
    val=insertNode(&((*n)->right),p);
  else{
    addPatient(*n,p);//just append patient to list
    return 1;
  }
  if(val==0){//if inserted a new node (not appended a patient to a node)
    (*n)->height=1+max(height((*n)->right),height((*n)->left));
    int balance=getBalance(*n);
    // Left Left Case
    if (balance > 1 && cmpDate(p->entry,(*n)->left->date)==-1){//key<node->left->key
        (*n)=rightRotate(*n);
        //printf("LEFT LEFT CASE\n");
        return val;
    }

    // Right Right Case
    if (balance < -1 && (cmpDate(p->entry,(*n)->right->date)==1)){//key>node->right->key
        (*n)=leftRotate(*n);
        //printf("RIGHT RIGHT CASE\n");
        return val;
    }
    // Left Right Case
    if (balance > 1 && cmpDate(p->entry,(*n)->left->date)==1){//key>node->left->key
        (*n)->left=leftRotate((*n)->left);
        (*n)=rightRotate(*n);
        //printf("LEFT RIGHT CASE\n");
        return val;
    }

    // Right Left Case
    if (balance < -1 && cmpDate(p->entry,(*n)->right->date)==-1){//key<node->right->key
        (*n)->right = rightRotate((*n)->right);
        (*n)=leftRotate(*n);
        //printf("RIGHT LEFT CASE\n");
        return val;
    }
  }
  return val;
}

int insertAvl(Avltree * tptr,Patient *pptr){//append patient if entry date exist else make a new node with other entry date
  //printf("Inserting: ");
  // printPatient(pptr);
  return insertNode(&tptr->root,pptr);

}

int recursive_count(Tnode * node,Date d1,Date d2,char * country,enum check_tp ch,enum patient_check p_ch){
                                                                          //recursively counts patients between this dates coming from country
  if(node==NULL)                                                         //country could be disease (usefull for topk-Countries)
    return 0;                                                           //if country ==NULL it doesnt check for country or disease

  int count=0;
  Patient * p;

  if(dateBetween(node->date,d1,d2) ||(d1.day==0 && d2.day==0)){//d.day==0 means nothing given
    for(int i=0;i<node->plist.size;i++){
      p=getPatient(&(node->plist),i);
      if(ch==COUNTRY){
        if(country==NULL || !strcmp(country,p->country)){
          if(p_ch!=EXITED || dateBetween(p->exit,d1,d2))
            count++;
        }
      }else{
        if(!strcmp(country,p->disease))//country str contains disease
          count++;
      }
    }
  }else if(cmpDate(node->date,d1)==-1){//if entrydate<d1 gotta check the exit date of each patient if between
    for(int i=0;i<node->plist.size;i++){
      p=getPatient(&(node->plist),i);
      if((cmpDate(d1,p->exit)==-1 && p_ch==FULL_CHECK) || (cmpDate(d1,p->exit)<1 && cmpDate(d2,p->exit)>-1 && p_ch==EXITED))//if d1<exit_date
        if(ch==COUNTRY || ch==NONE){
          if((country==NULL || !strcmp(country,p->country)))
            count++;
        }else{//disease
          if(!strcmp(country,p->disease))
            count++;
        }
    }
  }
  count+=recursive_count(node->left,d1,d2,country,ch,p_ch);
  if(cmpDate(node->date,d2)==-1 || (d1.day==0 && d2.day==0))
    count+=recursive_count(node->right,d1,d2,country,ch,p_ch);

  return count;
}

int  count_AgeRanges(Tnode * node,Date d1,Date d2,char * country,int ** arr_adr,int what){
  //this funct must always be called with parameter arr_adr as the adress of int * var containing NULL
  //at first when called the NULL will be replaced with the adress of malloced int array
  //indexes 0,1,2,3 belong to age ranges 0-20,21-40,41-60,60+ in that order
  //when done the arr_adr will contain the adress of array containing counter_values for each age range
  //the above happens in case of success (0 is returned indicating no error)-->user is responsible for freeing up the array creted in this funct
  //otherwise 1 is returned
  int ret_val;
  if(node==NULL && (*arr_adr==NULL))
    return 1;//means fail->empty root
  else if(node==NULL)
    return 0;//we came to an end

  Patient * p;
  if(*arr_adr==NULL){
    do{
      *arr_adr=malloc(4*sizeof(int));//it is 4 because we have 4 age ranges
    }while(*arr_adr==NULL);
    memset(*arr_adr,0,4*sizeof(int));//initialize counters
  }

  if(dateBetween(node->date,d1,d2) ||(d1.day==0 && d2.day==0)){//d.day==0 means nothing given
    for(int i=0;i<node->plist.size;i++){
      p=getPatient(&(node->plist),i);
      if(!strcmp(country,p->country)){
        if(p->age<=20)
          (*((*arr_adr)+0))++;
        else if(p->age<=40)
          (*((*arr_adr)+1))++;
        else if(p->age<=60)
          (*((*arr_adr)+2))++;
        else
          (*((*arr_adr)+3))++;
      }
    }
  }else if(what==1 && cmpDate(node->date,d1)==-1){//if im in topk case and entrydate<d1 gotta check the exit date of each patient if between
    for(int i=0;i<node->plist.size;i++){
      p=getPatient(&(node->plist),i);
      if(cmpDate(d1,p->exit)==-1)//if d1<exit_date
        if(!strcmp(country,p->country)){
          if(p->age<=20)
            (*((*arr_adr)+0))++;
          else if(p->age<=40)
            (*((*arr_adr)+1))++;
          else if(p->age<=60)
            (*((*arr_adr)+2))++;
          else
            (*((*arr_adr)+3))++;
        }
    }
  }

  count_AgeRanges(node->left,d1,d2,country,arr_adr,what);
  if(cmpDate(node->date,d2)==-1 || (d1.day==0 && d2.day==0))
    count_AgeRanges(node->right,d1,d2,country,arr_adr,what);

  return 0;

}


void nodeInorderprint(Tnode * n){//for debugging purposes
  if(n==NULL)
    return ;
  nodeInorderprint(n->left);
  printf("-------------------\n");
  printDate(n->date);
  printf("height: %d\n",n->height);
  printList(n->plist);
  nodeInorderprint(n->right);
  return ;
}

void printInorder(Avltree * tptr){
  nodeInorderprint(tptr->root);
  return ;
}

void destroyAvltree(Avltree * tptr){
  freeTnode(tptr->root);
  return ;
}
