#ifndef __AVLTREE_H__
#define __AVLTREE_H__
#include "../Patient/patient.h"
#include "../Date/date.h"
#include "../List/plist.h"
enum check_tp{COUNTRY,DISEASE,NONE};
enum patient_check{ENTERED,EXITED,FULL_CHECK};//usefull for recursive count -> for ex. we may want to count those that hospitalized in a period of time
                                            //or those that exited hospital in a period of time
                                          //or those tha was sick in this period of time (both the above cases or entered before and exited after)
typedef struct tnode{
  Date date;
  List plist;//list of patient with same entry date;
  int height;
  struct tnode * left;
  struct tnode * right;

}Tnode;

typedef struct avltree{
  Tnode * root;
}Avltree;

Tnode * newNode(Date date);
void addPatient(Tnode * n,Patient * p);
int insertNode(Tnode ** n,Patient * p);
Tnode * rightRotate(Tnode * x);
Tnode * leftRotate(Tnode * x);
int Patients_in_node(Tnode * n);
void freeTnode(Tnode * n);
int getBalance(Tnode *n);
int height(Tnode * n);
int max(int a, int b);

int recursive_count(Tnode * node,Date d1,Date d2,
  char * country,enum check_tp ch,enum patient_check p_ch);//recursively counts patients between this dates coming from country
                                                                                //country could be disease (usefull for topk-Countries)
                                                                              //if country ==NULL it doesnt check for country or disease
int count_AgeRanges(Tnode * node,Date d1,Date d2,char * country,int ** arr_adr,int what);//very similar to recursive count->check inside funct for comments
                                                                                    //0 is for summary stats and 1 is for topk
Avltree * newAvltree(void);
int insertAvl(Avltree * tptr,Patient *pptr);//append patient if entry date exist else make a new node with other entry date
void printInorder(Avltree * tptr);
void destroyAvltree(Avltree * tptr);

#endif
