#ifndef __PLIST_H__
#define __PLIST_H__
#include "../Patient/patient.h"

enum check{CHECKFORDUPLICATES,JUSTAPPEND};
enum destruction{FREE_DATA_MEMBERS,KEEP_DATA_MEMBERS};

typedef struct node{
  Patient * patient;
  struct node * next;
}Node;

typedef struct list{
  int size;
  Node * start;
}List;

Node * nodeAlloc(void);
void nodeInit(Node * nptr,Patient * pptr);
void nodesDestroy(Node *nptr,enum destruction dstr);
void listInit(List * lptr);
int listAppend(List * lptr,Patient * pptr,enum check chk);
void listDestroy(List * lptr,enum destruction dstr);
Patient * getPatient(List * lptr,int index);
Patient * getPatient_by_id(List *lptr,char * id);
void printList(List list);

#endif
