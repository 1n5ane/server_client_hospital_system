#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "plist.h"
#include "../Patient/patient.h"
#include "../Date/date.h"


Node * nodeAlloc(void){
  return malloc(sizeof(Node));
}

void nodeInit(Node * nptr,Patient * pptr){
  nptr->next=NULL;
  nptr->patient=pptr;//default copy is ok
}

void nodesDestroy(Node *nptr,enum destruction dstr){
  if(nptr==NULL)
    return ;
  nodesDestroy(nptr->next,dstr);
  if(dstr==FREE_DATA_MEMBERS){//this is usefull because i dont want double free when i destroy tree list
    freePatient(nptr->patient);//(data should be destroyed once in the original list)
    nptr->patient=NULL;
  }
  free(nptr);
  return;
}

void listInit(List * lptr){
  lptr->size=0;
  lptr->start=NULL;
}
int listAppend(List * lptr,Patient * pptr,enum check chk){//-1 indicates system error,1 indicates existence of patient
  if(lptr->start==NULL){
    lptr->size++;
    lptr->start=nodeAlloc();
    if(lptr->start==NULL){
      printf("Malloc error\n");
      return -1;
    }
    nodeInit(lptr->start,pptr);
    return 0;
  }

  Node * cur=lptr->start;
  if(chk==CHECKFORDUPLICATES)//dont insert if patient exist
    while(cur->next!=NULL){
      if(!strcmp((cur->patient)->id,pptr->id))//if patient already exists
        return 1;
      cur=cur->next;
    }
    if(!strcmp((cur->patient)->id,pptr->id))
      return 1;
  else//just append
    while(cur->next!=NULL){
      cur=cur->next;
    }

  cur->next=nodeAlloc();
  nodeInit(cur->next,pptr);
  lptr->size++;
  return 0;
}

void listDestroy(List * lptr,enum destruction dstr){
  lptr->size=0;
  nodesDestroy(lptr->start,dstr);
  lptr->start=NULL;
  return ;
}

Patient * getPatient(List * lptr,int index){
  if(index>=lptr->size)
    return NULL;
  Node * tmp=lptr->start;
  for(int i=1;i<=index;i++)
    tmp=tmp->next;

  return tmp->patient;
}

Patient * getPatient_by_id(List *lptr,char * id){
  Patient * pptr=NULL;
  Node * cur=lptr->start;
  while(cur!=NULL){
    if(!strcmp((cur->patient)->id,id)){
      pptr=cur->patient;
      break;
    }
    cur=cur->next;
  }
  return pptr;
}

void printList(List list){
  if(list.size==0){
    printf("List is empty!\n");
    return ;
  }else{
    printf("Size: %d\n",list.size);
  }

  Node * cur=list.start;
  for(int i=0;i<list.size;i++){
    printPatient(cur->patient);
    cur=cur->next;
  }
  return ;
}
