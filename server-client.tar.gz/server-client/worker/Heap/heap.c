#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "heap.h"

HNode * hnode_alloc(){
  HNode * ptr;
  do{
    ptr=malloc(sizeof(HNode));
  }while(ptr==NULL);
  return ptr;
}

void hnode_print(HNode * node,int which_node){
  if(node==NULL)
    return ;
  printf("Index:%d   %s %ld\theight: %d\n",which_node,node->str,node->infected,node->height);
  hnode_print(node->left,2*which_node);
  hnode_print(node->right,2*which_node + 1);
  return ;
}
void hnode_set(HNode * node,char * str,long int infected){
  node->height=1;
  node->str=str;
  node->infected=infected;
  node->left=NULL;
  node->right=NULL;
  return ;
}

int min(int a1,int a2){
  if(a1<=a2)
    return a1;
  return a2;
}

void swap_data(HNode * h1,HNode *h2){
  const char * str= h1->str;
  long int inf=h1->infected;
  h1->str=h2->str;
  h1->infected=h2->infected;
  h2->str=str;
  h2->infected=inf;
  return ;
}

int hnode_insert(HNode **node,int which_node,char * str,long int infected){//return val indicates from which child it returned -1 for left ,1 for right
  if(*node==NULL){
    *node=hnode_alloc();
    hnode_set(*node,str,infected);
    if(which_node%2==0)
      return -1;
    else
      return 1;
  }
  int val;

  if(get_height((*node)->left)<=get_height((*node)->right))
    val=hnode_insert(&((*node)->left),2*which_node,str,infected);
  else
    val=hnode_insert(&((*node)->right),2*which_node+1,str,infected);

  (*node)->height=min(get_height((*node)->left),get_height((*node)->right))+1;
  if(val==-1){//if came from left
    if((*node)->left->infected>(*node)->infected){//if left larger swap;
      swap_data((*node)->left,*node);
      if(which_node%2==0)
        return -1;
      else if(which_node!=1)
        return 1;
    }
  }else if (val==1){//came from right
    if((*node)->right->infected>(*node)->infected){//if left larger swap;
      swap_data((*node)->right,*node);
      if(which_node%2==0)
        return -1;
      else
        return 1;
    }
  }
  return 0;//0 indicates no need for other swaps because key is correctly placed
}

int get_height(HNode * node){
  if(node==NULL)
    return 0;
  return node->height;
}

void heap_init(Heap * hptr){
  hptr->size=0;
  hptr->root=NULL;
  return ;
}

Heap * heap_alloc(void){
  Heap * hptr;
  do{
    hptr=malloc(sizeof(Heap));
  }while(hptr==NULL);
  return hptr;
}

int heap_insert(Heap * hptr,char * virus,long int infected){
  hptr->size++;
  hnode_insert(&hptr->root,1,virus,infected);
}

void heap_print(Heap * hptr){
  printf("HEAP SIZE: %d\n",hptr->size);
  hnode_print(hptr->root,1);
  return ;
}

int hnode_destroy(HNode * node){
  if(node==NULL)
    return 0;
  hnode_destroy(node->left);
  hnode_destroy(node->right);
  free(node);
  return 0;
}

HNode * unlink_last_and_update_heights(HNode * node,int which_node,int *road,int next_step,int road_size){
  if(2*which_node==road[road_size-1]){//if last node is left children
    HNode * last=node->left;
    node->left=NULL;
    if(node->right!=NULL)//ama exei aderfo
      node->height--;
    return last;
  }else if((2*which_node + 1)==road[road_size-1]){//if last node is right children
    HNode * last=node->right;
    node->right=NULL;
    if(node->left!=NULL)//ama exei aderfo
      node->height--;
    return last;
  }
  HNode *ret_val;
  if(road[next_step]==-1)
    next_step++;
  if(2*which_node==road[next_step])//then go left
    ret_val=unlink_last_and_update_heights(node->left,2*which_node,road,next_step+1,road_size);
  else if(2*which_node+1==road[next_step])//then go right
    ret_val=unlink_last_and_update_heights(node->right,2*which_node+1,road,next_step+1,road_size);
  //update the height of current node
  node->height=min(get_height(node->left),get_height(node->right))+1;
  return ret_val;
}

int fix_violations(HNode *node){//finds correct place for new root
  if(node->left==NULL && node->right==NULL)//no more comparisons
    return 0;

  if((node->right==NULL) || ((node->left)->infected>=(node->right)->infected)){
    if(node->infected<(node->left)->infected){
      swap_data(node,node->left);
      fix_violations(node->left);
    }
  }else{
    if(node->infected<(node->right)->infected){
      swap_data(node,node->right);
      fix_violations(node->right);
    }
  }
}

int extract_max(Heap *hptr,const char **str,long int * infected){//0 in case of success,else 1
  if(hptr->size==0)
    return 1;
  *str=(hptr->root)->str;//keep the root values
  *infected=(hptr->root)->infected;
  if(hptr->size==1){//if only one node ->> no need for any of the following
    free(hptr->root);
    hptr->root=NULL;
    hptr->size--;
    return 0;
  }
  int count=hptr->size;
  int * road;
  do{
    road=malloc((hptr->root)->height*sizeof(int));
  }while(road==NULL);

  road[0]=-1;//height isnt always the same.if tree is full and a node leaves then the height will be decreased by 1(min height)
  int index=(hptr->root)->height-1;
  while(count!=1){
    road[index--]=count;
    count/=2;
  }
  //printf("To go to last %d the road is ",hptr->size);
  /*for(int i=0;i<hptr->root->height;i++)
    printf("%d ",road[i]);
  printf("\n");*/

  HNode * last=unlink_last_and_update_heights(hptr->root,1,road,0,(hptr->root)->height);
  free(road);
  swap_data(last,hptr->root);
  hptr->size--;
  if(hptr->size>1)//tote exei nohma
    fix_violations(hptr->root);//fins correct place for new root
  free(last);
  return 0;
}

int heap_destroy(Heap * hptr){
  hnode_destroy(hptr->root);
  free(hptr);
  return 0;
}
