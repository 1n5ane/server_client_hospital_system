#ifndef __HEAP_H__
#define __HEAP_H__

typedef struct hnode{
  int height;
  long int infected;
  const char * str;
  struct hnode * left;
  struct hnode * right;
}HNode;

typedef struct heap{
  int size;
  HNode* root;
}Heap;//max heap

void swap_data(HNode * h1,HNode *h2);
HNode * hnode_alloc();
void hnode_print(HNode * node,int which_node);
void hnode_set(HNode * node,char * virus,long int infected);
int get_height(HNode * node);
int hnode_insert(HNode **node,int which_node,char * str,long int infected);//return val indicates from which child it returned
int hnode_destroy(HNode * node);
                                                                            // -1 for left ,1 for right
HNode * unlink_last_and_update_heights(HNode * node,int which_node,int *road,int next_step,int road_size);
int fix_violations(HNode * node);//finds correct place for new root

int heap_destroy(Heap * hptr);
void heap_init(Heap * hptr);
int heap_insert(Heap * hptr,char * virus,long int infected);
Heap * heap_alloc(void);
void heap_print(Heap * hptr);
int extract_max(Heap *hptr,const char **str,long int * infected);
#endif
