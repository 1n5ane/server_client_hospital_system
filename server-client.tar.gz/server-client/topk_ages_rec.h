#ifndef __TOPK_RECORD_H__
#define __TOPK_RECORD_H__
#include <stdint.h>
typedef struct topk_ages_rec{
  char * category;
  int counter;
}Topk_ages_rec;
void set_topk(Topk_ages_rec * tptr,char * cat,int coun);
void destroy_topk(Topk_ages_rec * tptr);
void get_topk_from_raw_data(Topk_ages_rec *tptr,uint8_t * data,int how_many);
#endif
