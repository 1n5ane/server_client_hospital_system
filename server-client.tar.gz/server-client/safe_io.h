#ifndef __SAFE_IO_H__
#define __SAFE_IO_H__
#include <stdint.h>
int safe_read(int fd,uint8_t * buff,int size);//buff must be big enough for size
uint8_t * pipe_read(int fd,uint8_t * buff,int b_size,int r_size);//b_size is buffer size (may be smaller than r_size)
int safe_write(int fd,uint8_t * buff,int size);
//irrelevant funct
void get_country_name(char **country_name,char *country_path);
int word_count(char * line);

#endif
