#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include "worker/Date/date.h"
#include "safe_io.h"

int safe_read(int fd,uint8_t * buff,int size){//buff must be big enough for size
  int bytes_read=0;
  int total_bytes_read=0;
  while(total_bytes_read<size){
    bytes_read=read(fd,buff+total_bytes_read,size-total_bytes_read);
    if(bytes_read>0){
      total_bytes_read+=bytes_read;
    }else{//some error with read->may be interrupted by signal or the pipe is empty (O_NONBLOCK mode)
      if(errno==EBADF||errno==ECONNRESET){//if file descriptor is closed i got to make sure that i got everything
        return -1;
      }else
        continue;
    }
     // printf("%d bytes read\n",total_bytes_read);
  }
  return size;
}

uint8_t * pipe_read(int fd,uint8_t * buff,int b_size,int r_size){//b_size is buffer size (may be smaller than r_size)
  //if b_size smaller than r_size i return a malloced array that caller is obliged to free
  //if null is returned-> indicated something happened
  uint8_t * data;
  do{
    data=malloc(r_size);
  }while(data==NULL);
  int bytes_read=0;
  int position=0;
  while(r_size>0){
    if(b_size<r_size)
      bytes_read=safe_read(fd,buff,b_size);
    else
      bytes_read=safe_read(fd,buff,r_size);
    if(bytes_read==-1)//means that something happened to the other end
      return NULL;
    memcpy(data+position,buff,bytes_read);
    position+=bytes_read;
    r_size-=bytes_read;
  }
  return data;
}

int safe_write(int fd,uint8_t * buff,int size){
  int bytes_written=0;
  int total_bytes_written=0;
  while(total_bytes_written<size){
    bytes_written=write(fd,buff+total_bytes_written,size-total_bytes_written);
    if(bytes_written<0)//some error with read->may be interrupted by signal or who knows
      if(errno==EPIPE){
        //means that the other end(read end) closed beacuse child was killed!-->GOT TO HANDLE THIS
        return -1;
      }else
        continue;
    total_bytes_written+=bytes_written;
    // printf("%d bytes read\n",total_bytes_read);
  }

  return size;
}

//irrelevant to safe io
void get_country_name(char **country_name,char *country_path){
  int pos=0;
  int len=strlen(country_path);
  for(int i=0;i<len;i++){
    if(country_path[i]=='/' && i!=len-1)
      pos=i+1;
  }
  do{
    *country_name=malloc(strlen(country_path+pos)+1);
  }while(*country_name==NULL);
  strcpy(*country_name,country_path+pos);
  return ;
}

int word_count(char * line){
  int words=0;
  if(line[0]!=' ')
    words++;
  for(int i=1;i<strlen(line);i++){
    if(line[i]!=' ' && line[i-1]==' ')
      words++;
  }
  return words;
}
