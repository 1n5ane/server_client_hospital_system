#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <poll.h>
#include <signal.h>
#include <unistd.h>
#include <pthread.h>
#include <fcntl.h>
#include <semaphore.h>
#include "../worker/Date/date.h"
#include "../safe_io.h"

void my_handler(int signo){
  if(signo==SIGPIPE);

}
int thread_number;
int CLIENT_SLEEPING=0;
int connected_counter=0;
typedef struct sockaddr_in sockaddr_in;
typedef struct sockaddr sockaddr;
sockaddr_in server_addr;
enum worker_operations{SUMMARY_STATS,DISEASE_FREQUENCY,TOPK_AGERANGES,SEARCH_PATIENT,NUMPADMISSIONS,NUMPDISCHARGES};
sem_t main_notif;
pthread_mutex_t mutex=PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond=PTHREAD_COND_INITIALIZER;

void *client_thread(void * argp){
  int socket_fd;
  pthread_mutex_lock(&mutex);
  do{
    socket_fd=socket(AF_INET,SOCK_STREAM,0);
  }while(socket_fd<0);
  CLIENT_SLEEPING++;
  if(CLIENT_SLEEPING==thread_number)
    sem_post(&main_notif);//if im last thread inform main thread
  else
    pthread_cond_wait(&cond,&mutex);//all thread wait here until they get broadcast
  pthread_mutex_unlock(&mutex);
printf("\033[1m\033[28mTrying to connect [%ld]\033[0m\n",pthread_self());
  while(connect(socket_fd,(sockaddr *)&server_addr,sizeof(server_addr))<0){
    perror("\033[1m\033[31m-Handshake failed-\033[0m");
    sleep(1);
  }
  pthread_mutex_lock(&mutex);
  connected_counter++;
  pthread_mutex_unlock(&mutex);

  printf("\033[1m\033[28mConnected [%ld]\033[0m\n",pthread_self());

  int op_len=strlen(argp)+1;
  safe_write(socket_fd,(uint8_t *)&op_len,sizeof(int));//tell server what i need
  safe_write(socket_fd,(uint8_t *)argp,op_len);//tell server what i need
  usleep(50);//make sure that worker read the operation
  struct pollfd poll_fd;
  poll_fd.fd=socket_fd;
  poll_fd.events=POLLIN;
  int retval;
  char output[10240];
  int output_len=0;
  int len;
  int its_over=0;
  char ans[500];
  do{
    retval=poll(&poll_fd,(unsigned long)1,-1);
    if(retval<0){//interrupted

    }else if((poll_fd.revents&POLLIN)==POLLIN){//got the answer
      while((len=read(poll_fd.fd,ans,500))>0){
        sprintf(output+output_len,"%s",ans);
        output_len+=len;

      }
      write(0,output,output_len);
      its_over=1;
    }

  }while(!its_over);
  free(argp);
}

int main(int argc,char ** argv){
  if(argc!=9){
    printf("Error wrong use\n");//funct needed here for right use
    exit(1);
  }
  static struct sigaction act;
  act.sa_handler=my_handler;
  sigfillset(&act.sa_mask);
  sigaction(SIGPIPE,&act,NULL);//the default action is TERMINATE THIS PROCESS-->WE DONT WANT THAT!!
  int flag[4]={0};
  char * queryFile;
  int serverPort;
  char * serverIp;
  sem_init(&main_notif,0,0);//shared between threads of process
  for(int i=0;i<4;i++){
    if(!flag[0] && !strcmp(argv[2*i+1],"-q")){
      queryFile=argv[2*i+2];
      flag[0]=1;
    }else if(!flag[1] && !strcmp(argv[2*i+1],"-w")){
      thread_number=atoi(argv[2*i+2]);
      if(thread_number==0){
        printf("Buffersize can't be 0\n");
        exit(1);
      }
      flag[1]=1;
    }else if(!flag[2] && !strcmp(argv[2*i+1],"-sp")){
      serverPort=atoi(argv[2*i+2]);
      flag[2]=1;
    }else if(!flag[3] && !strcmp(argv[2*i+1],"-sip")){
      serverIp=argv[2*i+2];
      flag[3]=1;
    }else{
      printf("Error wrong parameters\n");//funct needed
      exit(1);
    }
  }
  server_addr.sin_family=AF_INET;
  server_addr.sin_port=htons(serverPort);
  if(!inet_aton(serverIp,&server_addr.sin_addr)){
    printf("Invalid server ip\n");
    exit(1);
  }

  FILE * fp=fopen(queryFile,"r");
  if(fp==NULL){
    perror("query file");
    exit(1);
  }
  pthread_t * thread_array;
  do{
    thread_array=malloc(thread_number*sizeof(pthread_t));
  }while(thread_array==NULL);

  char small_buffer[10];
  char virus_buffer[50];
  char country_buffer[50];
  char date1[15];
  char date2[15];
  char buffer[200];
  char user_choice[50];
  char * buffer_parameter;
  int words_in_line;
  enum worker_operations user_ch;
  for(int i=0;i<thread_number;i++){
    if(fgets(buffer,200,fp)==NULL)
      break;
    if(buffer[strlen(buffer)-1]=='\n')
      buffer[strlen(buffer)-1]='\0';
    do{
      buffer_parameter=malloc((strlen(buffer)+1));
    }while(buffer_parameter==NULL);
    strcpy(buffer_parameter,buffer);
    words_in_line=word_count(buffer_parameter);
    sscanf(buffer_parameter,"%s",user_choice);

    if(!strcmp("/diseaseFrequency",user_choice)){
      user_ch=DISEASE_FREQUENCY;
    }else if(!strcmp("/topk-AgeRanges",user_choice)){
      user_ch=TOPK_AGERANGES;
    }else if(!strcmp("/searchPatientRecord",user_choice)){
      user_ch=SEARCH_PATIENT;
    }else if(!strcmp("/numPatientAdmissions",user_choice)){
      user_ch=NUMPADMISSIONS;
    }else if(!strcmp("/numPatientDischarges",user_choice)){
      user_ch=NUMPDISCHARGES;
    }
    switch(user_ch){
      case DISEASE_FREQUENCY:
      case NUMPADMISSIONS:
      case NUMPDISCHARGES:
      ;
        char * countr_name=NULL;
        if(words_in_line==4){
          sscanf(buffer_parameter+strlen(user_choice)+1,"%s %s %s",virus_buffer,date1,date2);
        }else if(words_in_line==5){
          sscanf(buffer_parameter+strlen(user_choice)+1,"%s %s %s %s",virus_buffer,date1,date2,country_buffer);
          countr_name=country_buffer;
        }else{//error
          printf("error\n");
          free(buffer_parameter);
          break;
        }
        Date d1;
        Date d2;
        if(setDate(&d1,date1)||setDate(&d2,date2)){
          printf("error\n");
          free(buffer_parameter);
          break;
        }
        if(cmpDate(d1,d2)==1){//if d1 > d2
          printf("error\n");
          free(buffer_parameter);
          break;
        }
        pthread_create(&thread_array[i],NULL,client_thread,(void *)buffer_parameter);
        break;
      case TOPK_AGERANGES:
        if(words_in_line!=6){
          printf("error\n");
          free(buffer_parameter);
          break;
        }
        sscanf(buffer_parameter+strlen(user_choice)+1,"%s %s %s %s %s",small_buffer,country_buffer,virus_buffer,date1,date2);
        if(setDate(&d1,date1)||setDate(&d2,date2)){
          free(buffer_parameter);
          printf("error\n");
          break;
        }
        if(cmpDate(d1,d2)==1){//if d1 > d2
          free(buffer_parameter);
          printf("error\n");
          break;
        }
        pthread_create(&thread_array[i],NULL,client_thread,(void *)buffer_parameter);
        break;
      case SEARCH_PATIENT:

        if(words_in_line!=2){
          free(buffer_parameter);
          printf("error\n");
          break;
        }
        pthread_create(&thread_array[i],NULL,client_thread,(void *)buffer_parameter);
    }
  }
  printf("made %d client threads!\n",thread_number);
  sem_wait(&main_notif);//sleep until notified by last thread
  pthread_cond_broadcast(&cond);//wake up all thread to connect;

  for(int i=0;i<thread_number;i++)
    pthread_join(thread_array[i],NULL);

  printf("TOTAL CONNECTIONS MADE: %d\n",connected_counter);
  fclose(fp);
  free(thread_array);
  pthread_mutex_destroy(&mutex);
  pthread_cond_destroy(&cond);
  return 0;
}
