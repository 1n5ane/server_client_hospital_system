#!/bin/bash


#set -xv   # this line will enable debug

###functions needed
function get_Random_between(){ # use: get_Random_between result [num1] [num2]
    local  __resultvar=$1
    local  myresult
    if [ $2 -ge $3 ];then
      myresult=$2
    else
      myresult=$(($RANDOM%$(($3-$2 +1))+$2))
    fi
    eval $__resultvar="'$myresult'"
}

function get_Day_Month_Year(){ #use: get_Day_Month_Year date_str day month year ->when done these vars will have the values
  local __day=$2
  local __month=$3
  local __year=$4
  local __d
  local __m
  local __y
  local __str=$1
  __d=${__str:0:2}
  __d=${__d#0}
  __d=$(($__d + 0))
  __m=${__str:3:2}
  __m=${__m#0}
  __m=$(($__m + 0))
  __y=${__str:6:4}
  __y=$(($__y + 0))


  eval $__day="'$__d'"
  eval $__month="'$__m'"
  eval $__year="'$__y'"

}

function make_date(){ #use: make_date $d $m $y dt constructs dt string from d m y
  local __date_final=$4
  local __date_str=""
  if [ $1 -lt 10 ];then
    __date_str+="0$1"
  else
    __date_str+="$1"
  fi

  if [ $2 -lt 10 ];then
    __date_str+="-0$2"
  else
    __date_str+="-$2"
  fi
  __date_str+="-$3"
  eval $__date_final="'$__date_str'"

}

function date_arithmetics(){ #use date_arithmetics $date_str [+|-] $days_num
  local __arithmetics_d
  local __arithmetics_m
  local __arithmetics_y
  local __arithmetics_dt
  local __days_count=$3
  get_Day_Month_Year $1 __arithmetics_d __arithmetics_m __arithmetics_y
  while [ $__days_count -ge 30 ];do
    __arithmetics_m=$((($__arithmetics_m $2 1)%13))
    if [ $__arithmetics_m -eq 0 ];then
      if [ "$2" == "+" ];then
      __arithmetics_m=1
      __arithmetics_y=$(($__arithmetics_y + 1))
      else
        __arithmetics_m=12
        __arithmetics_y=$(($__arithmetics_y - 1))
      fi
    fi
    __days_count=$(($__days_count-30))
  done
    __arithmetics_d=$(($__arithmetics_d $2 $__days_count))
    if [ $__arithmetics_d -gt 30 ];then
      __arithmetics_d=$(($__arithmetics_d%30))
      __arithmetics_m=$(($__arithmetics_m + 1))
      if [ $__arithmetics_m -eq 13 ];then
        __arithmetics_m=1
        __arithmetics_y=$(($__arithmetics_y + 1))
      fi
    elif [ $__arithmetics_d -le 0 ];then
      __arithmetics_d=$((30 + $__arithmetics_d))
      __arithmetics_m=$(($__arithmetics_m - 1))
      if [ $__arithmetics_m -eq 0 ];then
        __arithmetics_m=12
        __arithmetics_y=$(($__arithmetics_y - 1))
      fi
    fi

  make_date $__arithmetics_d $__arithmetics_m $__arithmetics_y __arithmetics_dt
  echo $__arithmetics_dt
}

function date_cmp(){ #use: date_cmp date_str1 date_str2 -->output: echo 0 if same,-1 if 1st<2nd,1 if 1st>2nd
  local __date_cmp_d1;local __date_cmp_m1;local __date_cmp_y1
  local __date_cmp_d2;local __date_cmp_m2;local __date_cmp_y2
  get_Day_Month_Year $1 __date_cmp_d1 __date_cmp_m1 __date_cmp_y1
  get_Day_Month_Year $2 __date_cmp_d2 __date_cmp_m2 __date_cmp_y2
  if [ $__date_cmp_y1 -lt $__date_cmp_y2 ];then
    echo -1
  elif [ $__date_cmp_y1 -eq $__date_cmp_y2 ];then
    if [ $__date_cmp_m1 -lt $__date_cmp_m2 ];then
      echo -1
    elif [ $__date_cmp_m1 -eq $__date_cmp_m2 ];then
      if [ $__date_cmp_d1 -lt $__date_cmp_d2 ];then
        echo -1
      elif [ $__date_cmp_d1 -eq $__date_cmp_d2 ];then
        echo 0
      else
        echo 1
      fi
    else
      echo 1
    fi
  else
    echo 1
  fi
}

function get_Random_Date(){ #use: get_Random_Date date_str1 date_str2 ->get random date between these dates
  local __d1;local __m1;local __y1
  local __d2;local __m2;local __y2
  local __rand_d=0;local __rand_m=0;local __rand_y=0
  local __rand_date
  local __FLAG1=0;local __FLAG2=0
  get_Day_Month_Year $1 __d1 __m1 __y1
  get_Day_Month_Year $2 __d2 __m2 __y2

  while :
  do
    if [ $__y1 -eq $__y2 ];then
      __rand_y=$__y1
      __FLAG1=1
    else
      get_Random_between __rand_y $__y1 $__y2
    fi

    if [ $__m1 -eq $__m2 ];then
      __rand_m=$__m1
      __FLAG2=1
    elif [ $__m1 -gt $__m2 ];then
      get_Random_between __rand_m $(($__m2+1)) $__m1
      get_Random_between __rand_d 1 30
    else
      get_Random_between __rand_m $(($__m1+1)) $__m2
      get_Random_between __rand_d 1 30
    fi

    if [ $__FLAG2 -eq 1 ];then
      if [ $__FLAG1 -eq 1 ];then
        if [ $__d1 -ge $__d2 ];then
          get_Random_between __rand_d $__d2 30
        else
          get_Random_between __rand_d $__d1 30
        fi
      else
        if [ $__d1 -ge $__d2 ];then
          get_Random_between __rand_d $__d2 $__d1
        else
          get_Random_between __rand_d $__d1 $__d2
        fi
      fi
    fi
    make_date $__rand_d $__rand_m $__rand_y __rand_date
    local var=$(date_cmp $__rand_date $1)
    if [ $var -ge 0 ];then
      break
    fi
  done
  echo $__rand_date
}

function get_Random_str(){ # use: get_Random_id size_int
  cat /dev/urandom | tr -dc 'a-zA-Z' | fold -w $1 | head -n 1
}

function get_Random_id(){ # use: get_Random_id size_int
  if [ $1 -eq 1 ];then
    get_Random_between p 1 10
    if [ $p -gt 5 ];then #50% possibility
      cat /dev/urandom | tr -dc 'a-zA-Z' | fold -w $1 | head -n 1
    else
      cat /dev/urandom | tr -dc '0-9' | fold -w $1 | head -n 1
    fi
  else
    cat /dev/urandom | tr -dc '0-9' | fold -w $1 | head -n 1
  fi
}

function check_all_numbers(){
  local str=$1
  for((i=0;i<${#str};i++));do
    if ! [[ ${str:$i:1} =~ [0-9]  ]];then
      echo 0
      return 0
    fi
  done
  echo 1
}

args="$#"

if [ $args -ne 5 ];then
  echo "Parameters must be 5!"
  exit 1
fi

dfile=$1
cfile=$2
input_dir=$3
file_per_dir=$4
rec_per_file=$5

if [ $(check_all_numbers $4) -eq 0 ];then
  echo "Files per dir must be number!"
  exit 1
fi
if [ $(check_all_numbers $5) -eq 0 ];then
  echo "Records per file must be number!"
  exit 1
fi

# if [ ! -e $dfile ];then #if file doesn;t exist
#   echo "Disease file doesn't exist"
#   exit 1
# fi

if [ ! -e $cfile ];then # same as above
  echo "Country file doesn't exist"
  exit 1
fi

# creating input_dir.If exist i use this dir
if [ ! -e $input_dir ];then
  mkdir $input_dir
else
  echo $'Input dir already exists.\nWriting to this dir!'
fi
#its time to read the countries

countries=()
while IFS= read -r line
do
  countries+=("$line")
done < $cfile
c_size=${#countries[@]} #c_size is size of country array
cd $input_dir
for((i=0;i<$c_size;i++));do
  if [ ! -e "${countries[$i]}" ];then
    mkdir $"${countries[$i]}"
  else
    #echo "Dir ${countries[$i]} already exists"
    cd $"${countries[$i]}"
    files_in_dir=$(($(ls -l | wc -l)-1))
    if [ $files_in_dir -gt 0 ];then
      rm *
    fi
    cd ../
  fi
done
cd ../
diseases=()

while IFS= read -r line
do
  diseases+=("$line")
done < $dfile
d_size=${#diseases[@]} #d_size is size of diseases array

cd $input_dir

current_date=$(date +'%d-%m-%Y')
max_limit=$(date_arithmetics $current_date - $file_per_dir) # i'll get random dates until this limit
                                                        #if this limit is reached i'll get dates in order

for((i=0;i<$c_size;i++));do
  cd $"${countries[$i]}"
  lower_limit="01-01-2001" #starting date
  upper_limit=$(date_arithmetics $lower_limit + 198)
  if [ $i -ge 1 ];then
    unset date_file
  fi
  date_file=()
  for((j=0;j<$file_per_dir;j++));do
      # echo --------- $lower_limit $upper_limit
    ret_value=$(date_cmp $lower_limit $upper_limit)
    if [ $ret_value -ge 0 ];then
      res=$(date_cmp $(date_arithmetics $upper_limit + 198) $max_limit)
      if [ $res -ge 0 ];then # if reached the max limit get remaining days in order
        max_limit=$lower_limit
        for((k=$j;k<$file_per_dir;k++));do
          max_limit=$(date_arithmetics $max_limit + 1)
          touch $max_limit
          date_file+=("$max_limit")
        done
        break
      else # if reached upper limit but not max_limit just give more space to upper limit
        upper_limit=$(date_arithmetics $lower_limit + 198)
         # echo ***$lower_limit $upper_limit
      fi
    fi
    rand_date=$(get_Random_Date $lower_limit $upper_limit)

    touch $rand_date
    date_file+=("$rand_date")
    lower_limit=$(date_arithmetics $rand_date + 1)

  done

  for((k=0;k<$file_per_dir;k++));do
    lns=$(wc -l ${date_file[$k]} | cut -d ' ' -f1)
    #echo  "-->" ${date_file[$k]} $lns $'\n'
    for((j=$lns;j<$rec_per_file;j++));do
      get_Random_between name 3 12
      name="$(get_Random_str $name)"
      get_Random_between surname 3 12
      surname="$(get_Random_str $surname)"
      get_Random_between id_size 1 12
      id="$(get_Random_id $id_size)"
      get_Random_between d_index 0 $(($d_size-1))
      disease="${diseases[$d_index]}"
      get_Random_between age 1 120
      echo $id "ENTER" $name $surname $disease $age >> ${date_file[$k]}
      get_Random_between exit_pos 1 10
      if [ $exit_pos -le 6 ];then #exit posibillity is 60%
        get_Random_between exit_index $k $(($file_per_dir-1))
        lns=$(wc -l ${date_file[$exit_index]} | cut -d ' ' -f1)
        # echo ["ENTER" ${date_file[$k]}
        if [ $lns -lt $(($rec_per_file/2)) ];then #if no more than half of the records are exit
          echo $id "EXIT" $name $surname $disease $age >> ${date_file[$exit_index]}
          if [ $k -eq $exit_index ];then
            j=$(($j + 1))
            #echo "llllllll:"
          fi
        fi
        #echo "EXIT" ${date_file[$exit_index]}] $'\n'
      fi
      #printf "\n"
    done
  done
  cd ../
done
