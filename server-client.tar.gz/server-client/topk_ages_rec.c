#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "topk_ages_rec.h"

void set_topk(Topk_ages_rec * tptr,char * cat,int coun){
  do{
    tptr->category=malloc(strlen(cat)+1);
  }while(tptr->category==NULL);
  strcpy(tptr->category,cat);
  tptr->counter=coun;
  return ;
}
void destroy_topk(Topk_ages_rec * tptr){
  free(tptr->category);
  tptr->category=NULL;
  return ;
}
void get_topk_from_raw_data(Topk_ages_rec *tptr,uint8_t * data,int how_many){
  int len;

  for(int i=0;i<how_many;i++){
    len=*((int *)data);
    data+=sizeof(int);
    set_topk(&tptr[i],(char *)data,*(int *)(data+len));
    data+=sizeof(int);
    data+=len;
  }
  return ;
}
