#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <poll.h>
#include <dirent.h>
#include <semaphore.h>
#include <errno.h>
#include "../worker/Date/date.h"
#include "../safe_io.h"
#include "process_info.h"


enum worker_operations{SUMMARY_STATS,DISEASE_FREQUENCY,TOPK_AGERANGES,SEARCH_PATIENT,NUMPADMISSIONS,NUMPDISCHARGES,LISTCOUNTRIES,EXIT,ERROR,ALL_OK};
int workers;
Process_info *process_array;//i index is i worker with pid and two pipes
sem_t * worker_notif;
int SIGINT_COUNTER=0;//also counts SIGQUIT signals
int SIGCHLD_COUNTER=0;
pid_t dead_pid;
int who;
int termination_flag=1;
void my_handler(int signo){
  if(signo==SIGINT || signo==SIGQUIT){
    SIGINT_COUNTER++;
    termination_flag=0;
  }else if(signo==SIGCHLD){//something happened to the write end so i need to close the read end for the reads to fail
    SIGCHLD_COUNTER++;//also call wait to get the dead pid and store it to global var dead_pid
    int l;
    do{
      dead_pid=waitpid(-1,NULL,WNOHANG);
    }while(dead_pid==0);
    for(l=0;process_array[l].pid!=dead_pid;l++);
    who=l;
    // close(process_array[who].read_fd);
  }else if(signo==SIGUSR2)
    for(int i=0;i<workers-1;i++)
      sem_post(worker_notif);

}

int SUCCESS=0;
int FAIL=0;
int main(int argc,char **argv){
  //signal struct set up
  static struct sigaction act;
  act.sa_handler=my_handler;
  sigfillset(&act.sa_mask);
  sigaction(SIGUSR2,&act,NULL);//is for waking up the children

  int SIGINT_PREV_VAL=0;
  int SIGCHLD_PREV_VAL=0;
  if(argc!=11){
    printf("Error wrong use\n");//funct needed here for right use
    exit(1);
  }
  int flag[5]={0};
  int buffersize;
  char * server_ip_str;
  int server_port;

  char * input_dir=NULL;
  for(int i=0;i<5;i++){
    if(!flag[0] && !strcmp(argv[2*i+1],"-w")){
      workers=atoi(argv[2*i+2]);
      flag[0]=1;
    }else if(!flag[1] && !strcmp(argv[2*i+1],"-b")){
      buffersize=atoi(argv[2*i+2]);
      if(buffersize==0){
        if(input_dir!=NULL)
          free(input_dir);
        printf("Buffersize can't be 0\n");
        exit(1);
      }
      flag[1]=1;
    }else if(!flag[2] && !strcmp(argv[2*i+1],"-i")){
      input_dir=malloc(strlen(argv[2*i+2])+1);
      if(input_dir==NULL){
        printf("Malloc error!\n");
        exit(1);
      }
      strcpy(input_dir,argv[2*i+2]);
      flag[2]=1;
    }else if(!flag[3] && !strcmp(argv[2*i+1],"-s")){
      server_ip_str=argv[2*i+2];
      flag[3]=1;
    }else if(!flag[4] && !strcmp(argv[2*i+1],"-p")){
      server_port=atol(argv[2*i+2]);
      flag[4]=1;
    }else{
      printf("Error wrong parameters\n");//funct needed
      if(input_dir!=NULL)
        free(input_dir);
      exit(1);
    }
  }
  if(workers==0){
    free(input_dir);
    printf("Workers can't be 0\n");
    exit(1);
  }

/* check if workers>countries_in_dir so as not to fork so many workers */
  DIR * dir;
  struct stat dir_info;
  struct dirent * entry;
  char path_to_input_dir[200];
  strcpy(path_to_input_dir,input_dir);
  dir=opendir(input_dir);
  if(dir==NULL){
    perror("input_dir");
    free(input_dir);
    exit(1);
  }
  stat(input_dir,&dir_info);
  int countries_in_dir=dir_info.st_nlink;//this size contains "." and ".."
  char **country_name;
  do{
    country_name=malloc(countries_in_dir*sizeof(char *));
  }while(country_name==NULL);

  for(int i=0;i<dir_info.st_nlink;i++){
    entry=readdir(dir);
    do{
      country_name[i]=malloc(strlen(entry->d_name)+1);
    }while(country_name[i]==NULL);
    strcpy(country_name[i],entry->d_name);
  }

  if((countries_in_dir-2)<workers)
    workers=countries_in_dir-2;

  int countries_per_worker=(countries_in_dir-2)/workers;
  int left_overs=(countries_in_dir-2)%workers; //last worker may have more work to do than the others
  closedir(dir);
/*_____________________________________________________________________*/

  do{
    process_array=malloc(workers*sizeof(Process_info));
  }while(process_array==NULL);

  char rpipe[50];
  strcpy(rpipe,"../pipefiles/rpipe");
  for(int i=0;i<workers;i++){
    strcpy(rpipe,"../pipefiles/rpipe");
    sprintf(rpipe+strlen(rpipe),"%d",i);

    if(mkfifo(rpipe,0666)<0){
      perror("Error creating pipe for writing [master]");
      // FREEEEEE THE SPACE AND CLOSE EVERYTHING NEEDED
      exit(1);
    }

  }
  sem_t * mutex_sem=sem_open("/w_sem",O_CREAT|O_EXCL|O_TRUNC,0777,1);
  if(errno==EEXIST){
    sem_unlink("/w_sem");
    mutex_sem=sem_open("/w_sem",O_CREAT|O_EXCL|O_TRUNC,0777,1);
  }
  sem_close(mutex_sem);
  sem_t * workers_sync=sem_open("/s_sem",O_CREAT|O_EXCL|O_TRUNC,0777,workers-1);
  if(errno==EEXIST){
    sem_unlink("/s_sem");
    workers_sync=sem_open("/s_sem",O_CREAT|O_EXCL|O_TRUNC,0777,workers-1);
  }
  sem_close(workers_sync);
  worker_notif=sem_open("/n_sem",O_CREAT|O_EXCL|O_TRUNC,0777,0);
  if(errno==EEXIST){
    sem_unlink("/n_sem");
    worker_notif=sem_open("/n_sem",O_CREAT|O_EXCL|O_TRUNC,0777,workers-1);
  }

  int ip_len;
  pid_t ret_val;
  char id_buff[20];
  char bsize_buff[20];
  for(int i=0;i<workers;i++){
    strcpy(rpipe,"../pipefiles/rpipe");
    sprintf(rpipe+strlen(rpipe),"%d",i);
    do{
      ret_val=fork();
    }while(ret_val<0);
    if(ret_val==0){
      sprintf(id_buff,"%d",i);
      sprintf(bsize_buff,"%d",buffersize);
      if(execlp("../worker/worker","./worker",id_buff,bsize_buff,(char *)NULL)<0){
        perror("cant exec");
        exit(1);
      }
    }else{
      process_array[i].pid=ret_val;
    }
    do{
      ret_val=process_array[i].write_fd=open(rpipe,O_WRONLY|O_NONBLOCK|O_TRUNC);
    }while(ret_val<0);
    // printf("Opened to write %d [diseaseAggregator]\n",i);
  }
  char slash='/';
  int indx=0;
  enum worker_operations op=SUMMARY_STATS;
  kill(process_array[workers-1].pid,SIGUSR2);//inform worker he is the last
  for(int i=0;i<workers-1;i++){
    process_array[i].c_size=countries_per_worker;
    do{
      process_array[i].country=malloc(countries_per_worker*sizeof(char *));
    }while(process_array[i].country==NULL);
    safe_write(process_array[i].write_fd,(uint8_t *)&countries_per_worker,sizeof(int));//at first countries num
    safe_write(process_array[i].write_fd,(uint8_t *)&op,sizeof(enum worker_operations));//then what operation is it

    for(int k=0;k<countries_per_worker;k++){
      if(!strcmp(country_name[indx],".") || !strcmp(country_name[indx],"..")){
        indx++;
        k--;
        continue;
      }
      process_array[i].country[k]=country_name[indx];
      if(input_dir[strlen(input_dir)-1]!='/')
        strcat(path_to_input_dir,"/");
      strcat(path_to_input_dir,country_name[indx]);
      int len=strlen(path_to_input_dir)+1;
      safe_write(process_array[i].write_fd,(uint8_t *)&len,sizeof(int));
      safe_write(process_array[i].write_fd,(uint8_t *)path_to_input_dir,len);
      // printf("%s\n",path_to_input_dir);
      //then how many bytes ,then the message body <--this is done for each path


      strcpy(path_to_input_dir,input_dir);
    // printf("Wrote to %d\n",i);
      indx++;
    }
    int ip_len=strlen(server_ip_str)+1;
    safe_write(process_array[i].write_fd,(uint8_t *)&ip_len,sizeof(int));//how big the ip str
    safe_write(process_array[i].write_fd,(uint8_t *)server_ip_str,ip_len);//the ip str
    //and a long int that indicates port
    safe_write(process_array[i].write_fd,(uint8_t *)&server_port,sizeof(long int));
  }

  //the following is for last worker who may have more work...
  process_array[workers-1].c_size=countries_per_worker+left_overs;
  do{
    process_array[workers-1].country=malloc((countries_per_worker+left_overs)*sizeof(char *));
  }while(process_array[workers-1].country==NULL);
  safe_write(process_array[workers-1].write_fd,(uint8_t *)&process_array[workers-1].c_size,sizeof(int));//at first countries num
  safe_write(process_array[workers-1].write_fd,(uint8_t*)&op,sizeof(enum worker_operations));//then what operation is it

  for(int k=0;k<process_array[workers-1].c_size;k++){
    if(!strcmp(country_name[indx],".") || !strcmp(country_name[indx],"..")){
      indx++;
      k--;
      continue;
    }
    process_array[workers-1].country[k]=country_name[indx];
    if(input_dir[strlen(input_dir)-1]!='/')
      strcat(path_to_input_dir,"/");
    strcat(path_to_input_dir,country_name[indx]);
    int len=strlen(path_to_input_dir)+1;
    safe_write(process_array[workers-1].write_fd,(uint8_t *)&len,sizeof(int));
    safe_write(process_array[workers-1].write_fd,(uint8_t *)path_to_input_dir,len);
    // printf("%s\n",path_to_input_dir);

    //then how many bytes ,then the message body <--this is done for each path


    strcpy(path_to_input_dir,input_dir);
  // printf("Wrote to %d\n",i);
    indx++;
  }
  ip_len=strlen(server_ip_str)+1;
  safe_write(process_array[workers-1].write_fd,(uint8_t *)&ip_len,sizeof(int));//how big the ip str
  safe_write(process_array[workers-1].write_fd,(uint8_t *)server_ip_str,ip_len);//the ip str
  //and a long int that indicates port
  safe_write(process_array[workers-1].write_fd,(uint8_t *)&server_port,sizeof(int));

  char * read_buffer;
  do{
    read_buffer=malloc(buffersize);
  }while(read_buffer==NULL);

  sigaction(SIGALRM,&act,NULL);
  sigaction(SIGCHLD,&act,NULL);
  sigaction(SIGINT,&act,NULL);
  sigaction(SIGQUIT,&act,NULL);
  sigaction(SIGPIPE,&act,NULL);//the default action is TERMINATE THIS PROCESS-->WE DONT WANT THAT!!
  int val;
  int len;
  while(termination_flag){
    pause();//if someone dies pause will be interrupted
    if(!termination_flag)
      break;
    if(errno==EINTR){
    //if interrupted by a signal check if someone died or something else
      if(SIGCHLD_PREV_VAL<SIGCHLD_COUNTER){//got SIGCHLD signal
        printf("------->  %ld died!\n",(long int)dead_pid);
        strcpy(rpipe,"../pipefiles/rpipe");
        sprintf(rpipe+strlen(rpipe),"%d",who);
    /*    BRING BACK THE DEAD TRUNC THE PIPE AND OPEN AND TELL TO SEND SUMMARY STATS */
        close(process_array[who].write_fd);
        unlink(rpipe);
        if(mkfifo(rpipe,0666)<0){
          perror("Error creating pipe for writing [master]");
          // FREEEEEE THE SPACE AND CLOSE EVERYTHING NEEDED
          exit(1);
        }

        do{
          ret_val=fork();
        }while(ret_val<0);
        if(ret_val==0){
          sprintf(id_buff,"%d",who);
          sprintf(bsize_buff,"%d",buffersize);
          if(execlp("../worker/worker","./worker",id_buff,bsize_buff,(char *)NULL)<0){
            perror("cant exec");
            exit(1);
          }
        }else{
          process_array[who].pid=ret_val;
        }

        do{
          ret_val=process_array[who].write_fd=open(rpipe,O_WRONLY|O_NONBLOCK|O_TRUNC);
        }while(ret_val<0);
        safe_write(process_array[who].write_fd,(uint8_t *)&process_array[who].c_size,sizeof(int));//at first countries num
        op=SUMMARY_STATS;
        safe_write(process_array[who].write_fd,(uint8_t*)&op,sizeof(enum worker_operations));//then what operation is it

        strcpy(path_to_input_dir,input_dir);
        for(int l=0;l<process_array[who].c_size;l++){
          if(input_dir[strlen(input_dir)-1]!='/')
            strcat(path_to_input_dir,"/");
          strcat(path_to_input_dir,process_array[who].country[l]);
          len=strlen(path_to_input_dir)+1;
          safe_write(process_array[who].write_fd,(uint8_t *)&len,sizeof(int));
          safe_write(process_array[who].write_fd,(uint8_t *)path_to_input_dir,len);
          strcpy(path_to_input_dir,input_dir);
        }
        safe_write(process_array[who].write_fd,(uint8_t *)&ip_len,sizeof(int));//how big the ip str
        safe_write(process_array[who].write_fd,(uint8_t *)server_ip_str,ip_len);//the ip str
        //and a long int that indicates port
        safe_write(process_array[who].write_fd,(uint8_t *)&server_port,sizeof(int));
        SIGCHLD_PREV_VAL=SIGCHLD_COUNTER;
      }else
        continue;
    }
  }

  for(int i=0;i<workers;i++){
    strcpy(rpipe,"../pipefiles/rpipe");
    close(process_array[i].write_fd);//the read fds are closed by the handler that handles SIGCHLD
    sprintf(rpipe+strlen(rpipe),"%d",i);
    unlink(rpipe);
    free(process_array[i].country);
  }
  free(read_buffer);
  free(input_dir);
  for(int i=0;i<countries_in_dir;i++)
    free(country_name[i]);
  free(country_name);
  free(process_array);
  sem_close(worker_notif);
  return 0;
}
