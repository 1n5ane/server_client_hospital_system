#ifndef __PROCESS_INFO_H__
#define __PROCESS_INFO_H
typedef struct process{
  pid_t pid;
  int c_size;
  char **country;
  int read_fd;
  int write_fd;
}Process_info;
#endif
